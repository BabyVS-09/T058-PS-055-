package com.ats;

import com.ats.model.GradeBand;
import com.ats.model.Interviewer;
import com.ats.parser.CommandExecutionResult;
import com.ats.parser.CommandFileParser;
import com.ats.service.RecruitmentService;

import java.io.File;
import java.util.List;

/**
 * CLI Entry point for PS-055 Recruitment ATS.
 * Team T058 - Baby V S (1AT24CG012) and Bhagyashree Rama Naik (1AT24CG013).
 */
public class Main {

    public static void main(String[] args) {
        String filePath = (args != null && args.length > 0) ? args[0] : "sample-data/happy-path.txt";
        File commandFile = new File(filePath);

        System.out.println("================================================================================");
        System.out.println("PS-055: Recruitment ATS with Interview Scheduling and Offer Approval Matrix");
        System.out.println("Team T058 | Baby V S (1AT24CG012) & Bhagyashree Rama Naik (1AT24CG013)");
        System.out.println("Command File: " + filePath);
        System.out.println("================================================================================");

        RecruitmentService recruitmentService = new RecruitmentService();

        // Seed default interviewer panel across grade bands
        recruitmentService.registerInterviewer(new Interviewer("INT-101", "Kavita Rao", GradeBand.G3));
        recruitmentService.registerInterviewer(new Interviewer("INT-102", "Vikram Desai", GradeBand.G5));
        recruitmentService.registerInterviewer(new Interviewer("INT-103", "Anand Kulkarni", GradeBand.G4));
        recruitmentService.registerInterviewer(new Interviewer("INT-104", "Pooja Hegde", GradeBand.G6));

        CommandFileParser parser = new CommandFileParser(recruitmentService);

        try {
            List<CommandExecutionResult> results = parser.parseAndExecute(commandFile);
            long succeeded = results.stream().filter(CommandExecutionResult::success).count();
            long failed = results.stream().filter(r -> !r.success()).count();

            System.out.println("================================================================================");
            System.out.println("Execution Complete | Commands Processed: " + results.size()
                    + " | Succeeded: " + succeeded + " | Rejected/Errors: " + failed);
            System.out.println("================================================================================");
        } catch (Exception e) {
            System.err.println("[FATAL] Failed to process command file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

package com.ats.model;

/**
 * Source through which candidate entered the recruitment pipeline.
 */
public enum CandidateSource {
    REFERRAL,
    PORTAL,
    AGENCY,
    INTERNAL;

    public static CandidateSource from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("CandidateSource value cannot be null or empty.");
        }
        return CandidateSource.valueOf(value.trim().toUpperCase());
    }
}

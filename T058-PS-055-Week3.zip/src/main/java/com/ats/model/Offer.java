package com.ats.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * Offer entity capturing compensation, bonuses, recruitment fees, validity, and approval status.
 */
public class Offer {
    private final String offerId;
    private final String applicationId;
    private final String candidateId;
    private final String requisitionId;
    private final BigDecimal currentCtc;
    private final BigDecimal expectedCtc;
    private final BigDecimal offeredCtc;
    private final BigDecimal joiningBonus;
    private final BigDecimal buyoutReimbursement;
    private final BigDecimal recruitmentFee;
    private final BigDecimal totalCost;
    private final boolean outOfBand;
    private final boolean requiresVpApproval;
    private final boolean requiresCfoApproval;
    private final LocalDate offerDate;
    private final LocalDate targetJoiningDate;
    private final LocalDateTime validUntil; // Day 7 at 23:59:59.999999999
    private OfferStatus status;
    private ApprovalMatrix approvalMatrix;

    public Offer(String offerId, String applicationId, String candidateId, String requisitionId,
                 BigDecimal currentCtc, BigDecimal expectedCtc, BigDecimal offeredCtc,
                 BigDecimal joiningBonus, BigDecimal buyoutReimbursement,
                 BigDecimal recruitmentFee, BigDecimal totalCost,
                 boolean outOfBand, boolean requiresVpApproval, boolean requiresCfoApproval,
                 LocalDate offerDate, LocalDate targetJoiningDate) {
        this.offerId = offerId;
        this.applicationId = applicationId;
        this.candidateId = candidateId;
        this.requisitionId = requisitionId;
        this.currentCtc = currentCtc.setScale(2, RoundingMode.HALF_UP);
        this.expectedCtc = expectedCtc.setScale(2, RoundingMode.HALF_UP);
        this.offeredCtc = offeredCtc.setScale(2, RoundingMode.HALF_UP);
        this.joiningBonus = joiningBonus.setScale(2, RoundingMode.HALF_UP);
        this.buyoutReimbursement = buyoutReimbursement.setScale(2, RoundingMode.HALF_UP);
        this.recruitmentFee = recruitmentFee.setScale(2, RoundingMode.HALF_UP);
        this.totalCost = totalCost.setScale(2, RoundingMode.HALF_UP);
        this.outOfBand = outOfBand;
        this.requiresVpApproval = requiresVpApproval;
        this.requiresCfoApproval = requiresCfoApproval;
        this.offerDate = offerDate;
        this.targetJoiningDate = targetJoiningDate;
        // Valid for 7 calendar days: Day 7 at 23:59:59 is valid, Day 8 at 00:00 is invalid.
        // offerDate is day 1, offerDate.plusDays(7) at 23:59:59.999 is valid
        this.validUntil = offerDate.plusDays(7).atTime(LocalTime.MAX);
        this.status = OfferStatus.DRAFT;
    }

    public String getOfferId() {
        return offerId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public String getRequisitionId() {
        return requisitionId;
    }

    public BigDecimal getCurrentCtc() {
        return currentCtc;
    }

    public BigDecimal getExpectedCtc() {
        return expectedCtc;
    }

    public BigDecimal getOfferedCtc() {
        return offeredCtc;
    }

    public BigDecimal getJoiningBonus() {
        return joiningBonus;
    }

    public BigDecimal getBuyoutReimbursement() {
        return buyoutReimbursement;
    }

    public BigDecimal getRecruitmentFee() {
        return recruitmentFee;
    }

    public BigDecimal getTotalCost() {
        return totalCost;
    }

    public boolean isOutOfBand() {
        return outOfBand;
    }

    public boolean isRequiresVpApproval() {
        return requiresVpApproval;
    }

    public boolean isRequiresCfoApproval() {
        return requiresCfoApproval;
    }

    public LocalDate getOfferDate() {
        return offerDate;
    }

    public LocalDate getTargetJoiningDate() {
        return targetJoiningDate;
    }

    public LocalDateTime getValidUntil() {
        return validUntil;
    }

    public OfferStatus getStatus() {
        return status;
    }

    public void setStatus(OfferStatus status) {
        this.status = status;
    }

    public ApprovalMatrix getApprovalMatrix() {
        return approvalMatrix;
    }

    public void setApprovalMatrix(ApprovalMatrix approvalMatrix) {
        this.approvalMatrix = approvalMatrix;
    }

    /**
     * Checks whether this offer is still valid at evaluationDateTime.
     * Rule F:
     * - Offers valid for seven calendar days.
     * - Day 7 at 23:59 is valid.
     * - Day 8 at 00:00 is invalid.
     */
    public boolean isValidAt(LocalDateTime evaluationDateTime) {
        return !evaluationDateTime.isAfter(validUntil);
    }
}

package com.ats.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * An individual step in the sequential approval matrix.
 */
public class ApprovalStep {
    private final int stepNumber;
    private final ApprovalRole role;
    private final String approverName;
    private final LocalDate assignedDate;
    private final LocalDate deadlineDate; // 2 working days SLA
    private ApprovalStatus status;
    private LocalDateTime actionTimestamp;
    private String remarks;

    public ApprovalStep(int stepNumber, ApprovalRole role, String approverName,
                        LocalDate assignedDate, LocalDate deadlineDate) {
        this.stepNumber = stepNumber;
        this.role = role;
        this.approverName = approverName;
        this.assignedDate = assignedDate;
        this.deadlineDate = deadlineDate;
        this.status = ApprovalStatus.PENDING;
    }

    public int getStepNumber() {
        return stepNumber;
    }

    public ApprovalRole getRole() {
        return role;
    }

    public String getApproverName() {
        return approverName;
    }

    public LocalDate getAssignedDate() {
        return assignedDate;
    }

    public LocalDate getDeadlineDate() {
        return deadlineDate;
    }

    public ApprovalStatus getStatus() {
        return status;
    }

    public void setStatus(ApprovalStatus status) {
        this.status = status;
    }

    public LocalDateTime getActionTimestamp() {
        return actionTimestamp;
    }

    public void setActionTimestamp(LocalDateTime actionTimestamp) {
        this.actionTimestamp = actionTimestamp;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean isDecided() {
        return status == ApprovalStatus.APPROVED || status == ApprovalStatus.REJECTED;
    }

    @Override
    public String toString() {
        return "ApprovalStep{" +
                "step=" + stepNumber +
                ", role=" + role +
                ", approver='" + approverName + '\'' +
                ", deadline=" + deadlineDate +
                ", status=" + status +
                '}';
    }
}

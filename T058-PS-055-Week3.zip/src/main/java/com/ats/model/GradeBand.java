package com.ats.model;

/**
 * Grade bands from G1 (entry-level) to G6 (leadership/executive).
 */
public enum GradeBand {
    G1,
    G2,
    G3,
    G4,
    G5,
    G6;

    public boolean isHigherThan(GradeBand other) {
        return this.ordinal() > other.ordinal();
    }

    public boolean isAtLeastOneGradeHigherThan(GradeBand other) {
        return this.ordinal() >= other.ordinal() + 1;
    }

    public static GradeBand from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("GradeBand value cannot be null or empty.");
        }
        return GradeBand.valueOf(value.trim().toUpperCase());
    }
}

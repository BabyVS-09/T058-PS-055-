package com.ats.model;

import java.time.LocalDateTime;

/**
 * Immutable audit record for an ATS application stage transition.
 */
public record StageTransitionRecord(
        CandidateStage fromStage,
        CandidateStage toStage,
        LocalDateTime timestamp,
        ReasonCode reasonCode,
        String message
) {
    public StageTransitionRecord(CandidateStage fromStage, CandidateStage toStage, ReasonCode reasonCode, String message) {
        this(fromStage, toStage, LocalDateTime.now(), reasonCode, message);
    }
}

package com.ats.model;

/**
 * Standard checked/unchecked exception for business-rule violations in PS-055 ATS.
 */
public class AtsException extends RuntimeException {
    private final ReasonCode reasonCode;

    public AtsException(ReasonCode reasonCode, String message) {
        super(message);
        this.reasonCode = reasonCode;
    }

    public AtsException(ReasonCode reasonCode, String message, Throwable cause) {
        super(message, cause);
        this.reasonCode = reasonCode;
    }

    public ReasonCode getReasonCode() {
        return reasonCode;
    }

    @Override
    public String toString() {
        return "[" + reasonCode + "] " + getMessage();
    }
}

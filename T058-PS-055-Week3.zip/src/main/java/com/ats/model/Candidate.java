package com.ats.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * Candidate profile entity.
 */
public class Candidate {
    private final String candidateId;
    private final String name;
    private final int noticePeriodDays;
    private final BigDecimal currentCtc;
    private final BigDecimal expectedCtc;
    private final BigDecimal experienceYears;
    private final CandidateSource source;

    public Candidate(String candidateId, String name, int noticePeriodDays,
                     BigDecimal currentCtc, BigDecimal expectedCtc,
                     BigDecimal experienceYears, CandidateSource source) {
        if (candidateId == null || candidateId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Candidate ID cannot be null or empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Candidate name cannot be null or empty.");
        }
        if (noticePeriodDays < 0) {
            throw new AtsException(ReasonCode.INVALID_NOTICE_PERIOD, "Notice period days cannot be negative.");
        }
        if (currentCtc == null || currentCtc.compareTo(BigDecimal.ZERO) < 0) {
            throw new AtsException(ReasonCode.INVALID_CTC, "Current CTC cannot be negative.");
        }
        if (expectedCtc == null || expectedCtc.compareTo(BigDecimal.ZERO) <= 0) {
            throw new AtsException(ReasonCode.INVALID_CTC, "Expected CTC must be strictly greater than zero.");
        }
        if (experienceYears == null || experienceYears.compareTo(BigDecimal.ZERO) < 0) {
            throw new AtsException(ReasonCode.INVALID_EXPERIENCE, "Experience years cannot be negative.");
        }
        if (source == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Candidate source cannot be null.");
        }

        this.candidateId = candidateId.trim();
        this.name = name.trim();
        this.noticePeriodDays = noticePeriodDays;
        this.currentCtc = currentCtc.setScale(2, RoundingMode.HALF_UP);
        this.expectedCtc = expectedCtc.setScale(2, RoundingMode.HALF_UP);
        this.experienceYears = experienceYears.setScale(1, RoundingMode.HALF_UP);
        this.source = source;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public String getName() {
        return name;
    }

    public int getNoticePeriodDays() {
        return noticePeriodDays;
    }

    public BigDecimal getCurrentCtc() {
        return currentCtc;
    }

    public BigDecimal getExpectedCtc() {
        return expectedCtc;
    }

    public BigDecimal getExperienceYears() {
        return experienceYears;
    }

    public CandidateSource getSource() {
        return source;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Candidate candidate)) return false;
        return Objects.equals(candidateId, candidate.candidateId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(candidateId);
    }

    @Override
    public String toString() {
        return "Candidate{" +
                "candidateId='" + candidateId + '\'' +
                ", name='" + name + '\'' +
                ", noticePeriodDays=" + noticePeriodDays +
                ", currentCtc=" + currentCtc +
                ", expectedCtc=" + expectedCtc +
                ", experienceYears=" + experienceYears +
                ", source=" + source +
                '}';
    }
}

package com.ats.model;

import java.util.EnumSet;
import java.util.Set;

/**
 * All 14 stages in the recruitment pipeline state machine.
 */
public enum CandidateStage {
    SCREENED,
    L1,
    L2,
    HR,
    OFFER_DRAFT,
    OFFER_APPROVED,
    OFFERED,
    ACCEPTED,
    DECLINED,
    JOINED,
    REJECTED,
    WAITLIST,
    ON_HOLD,
    WITHDRAWN;

    private static final Set<CandidateStage> TERMINAL_STAGES = EnumSet.of(
            JOINED,
            REJECTED,
            DECLINED,
            WITHDRAWN
    );

    private static final Set<CandidateStage> OFFER_HOLDING_STAGES = EnumSet.of(
            OFFER_DRAFT,
            OFFER_APPROVED,
            OFFERED,
            ACCEPTED,
            JOINED
    );

    public boolean isTerminal() {
        return TERMINAL_STAGES.contains(this);
    }

    public boolean isOfferHolding() {
        return OFFER_HOLDING_STAGES.contains(this);
    }

    public static CandidateStage from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("CandidateStage cannot be null or empty.");
        }
        return CandidateStage.valueOf(value.trim().toUpperCase());
    }
}

package com.ats.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

/**
 * Job requisition entity.
 */
public class Requisition {
    private final String requisitionId;
    private final String role;
    private final GradeBand gradeBand;
    private final int headcount;
    private int reservedHeadcount;
    private int joinedHeadcount;
    private final String location;
    private final BigDecimal minCtc;
    private final BigDecimal maxCtc;
    private final String hiringManager;
    private final LocalDate openedDate;
    private RequisitionStatus status;

    public Requisition(String requisitionId, String role, GradeBand gradeBand,
                       int headcount, String location,
                       BigDecimal minCtc, BigDecimal maxCtc,
                       String hiringManager, LocalDate openedDate) {
        if (requisitionId == null || requisitionId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Requisition ID cannot be null or empty.");
        }
        if (role == null || role.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Role cannot be null or empty.");
        }
        if (gradeBand == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Grade band cannot be null.");
        }
        if (headcount <= 0) {
            throw new AtsException(ReasonCode.INVALID_HEADCOUNT, "Headcount must be strictly greater than zero.");
        }
        if (minCtc == null || minCtc.compareTo(BigDecimal.ZERO) <= 0) {
            throw new AtsException(ReasonCode.INVALID_CTC, "Minimum CTC must be strictly greater than zero.");
        }
        if (maxCtc == null || maxCtc.compareTo(BigDecimal.ZERO) <= 0) {
            throw new AtsException(ReasonCode.INVALID_CTC, "Maximum CTC must be strictly greater than zero.");
        }
        if (minCtc.compareTo(maxCtc) > 0) {
            throw new AtsException(ReasonCode.INVALID_CTC, "Minimum CTC (" + minCtc + ") cannot exceed Maximum CTC (" + maxCtc + ").");
        }
        if (hiringManager == null || hiringManager.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Hiring manager cannot be null or empty.");
        }
        if (openedDate == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Opened date cannot be null.");
        }

        this.requisitionId = requisitionId.trim();
        this.role = role.trim();
        this.gradeBand = gradeBand;
        this.headcount = headcount;
        this.reservedHeadcount = 0;
        this.joinedHeadcount = 0;
        this.location = (location == null || location.trim().isEmpty()) ? "Remote" : location.trim();
        this.minCtc = minCtc.setScale(2, RoundingMode.HALF_UP);
        this.maxCtc = maxCtc.setScale(2, RoundingMode.HALF_UP);
        this.hiringManager = hiringManager.trim();
        this.openedDate = openedDate;
        this.status = RequisitionStatus.OPEN;
    }

    public String getRequisitionId() {
        return requisitionId;
    }

    public String getRole() {
        return role;
    }

    public GradeBand getGradeBand() {
        return gradeBand;
    }

    public int getHeadcount() {
        return headcount;
    }

    public synchronized int getReservedHeadcount() {
        return reservedHeadcount;
    }

    public synchronized int getJoinedHeadcount() {
        return joinedHeadcount;
    }

    public synchronized int getAvailableHeadcount() {
        int occupied = reservedHeadcount + joinedHeadcount;
        return Math.max(0, headcount - occupied);
    }

    public synchronized boolean hasAvailableHeadcount() {
        return (reservedHeadcount + joinedHeadcount) < headcount;
    }

    public synchronized boolean reserveHeadcount() {
        if (!hasAvailableHeadcount()) {
            return false;
        }
        this.reservedHeadcount++;
        return true;
    }

    public synchronized boolean releaseHeadcount() {
        if (this.reservedHeadcount > 0) {
            this.reservedHeadcount--;
            return true;
        }
        return false;
    }

    public synchronized void markCandidateJoined() {
        if (this.reservedHeadcount > 0) {
            this.reservedHeadcount--;
        }
        this.joinedHeadcount++;
    }

    public String getLocation() {
        return location;
    }

    public BigDecimal getMinCtc() {
        return minCtc;
    }

    public BigDecimal getMaxCtc() {
        return maxCtc;
    }

    public String getHiringManager() {
        return hiringManager;
    }

    public LocalDate getOpenedDate() {
        return openedDate;
    }

    public RequisitionStatus getStatus() {
        return status;
    }

    public void setStatus(RequisitionStatus status) {
        this.status = status;
    }

    /**
     * Updates ageing status based on current evaluation date.
     * Rule G:
     * - Requisition becomes AT_RISK after 45 days.
     * - Automatically close after 90 days unless headcount is reserved.
     *
     * @param currentDate date against which to evaluate ageing
     * @return true if requisition was automatically closed
     */
    public synchronized boolean updateAgeing(LocalDate currentDate) {
        if (status == RequisitionStatus.CLOSED) {
            return false;
        }
        long daysOpen = ChronoUnit.DAYS.between(openedDate, currentDate);
        if (daysOpen >= 90) {
            // Automatically close after 90 days unless headcount is reserved
            if (reservedHeadcount == 0 && joinedHeadcount < headcount) {
                this.status = RequisitionStatus.CLOSED;
                return true;
            } else if (reservedHeadcount > 0) {
                // If headcount is reserved, it stays open or AT_RISK
                this.status = RequisitionStatus.AT_RISK;
                return false;
            }
        } else if (daysOpen >= 45) {
            this.status = RequisitionStatus.AT_RISK;
        } else {
            this.status = RequisitionStatus.OPEN;
        }
        return false;
    }

    public long getDaysOpen(LocalDate currentDate) {
        return ChronoUnit.DAYS.between(openedDate, currentDate);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Requisition that)) return false;
        return Objects.equals(requisitionId, that.requisitionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(requisitionId);
    }

    @Override
    public String toString() {
        return "Requisition{" +
                "requisitionId='" + requisitionId + '\'' +
                ", role='" + role + '\'' +
                ", gradeBand=" + gradeBand +
                ", headcount=" + headcount +
                ", reserved=" + reservedHeadcount +
                ", joined=" + joinedHeadcount +
                ", minCtc=" + minCtc +
                ", maxCtc=" + maxCtc +
                ", status=" + status +
                '}';
    }
}

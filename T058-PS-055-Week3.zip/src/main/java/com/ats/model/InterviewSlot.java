package com.ats.model;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Scheduled interview slot representation.
 */
public class InterviewSlot {
    private final String slotId;
    private final String applicationId;
    private final String candidateId;
    private final String interviewerId;
    private final GradeBand interviewerGrade;
    private final InterviewRound round;
    private final LocalDateTime startDateTime;
    private final LocalDateTime endDateTime;

    public InterviewSlot(String slotId, String applicationId, String candidateId,
                         String interviewerId, GradeBand interviewerGrade,
                         InterviewRound round, LocalDateTime startDateTime,
                         LocalDateTime endDateTime) {
        this.slotId = slotId;
        this.applicationId = applicationId;
        this.candidateId = candidateId;
        this.interviewerId = interviewerId;
        this.interviewerGrade = interviewerGrade;
        this.round = round;
        this.startDateTime = startDateTime;
        this.endDateTime = endDateTime;
    }

    public String getSlotId() {
        return slotId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public String getInterviewerId() {
        return interviewerId;
    }

    public GradeBand getInterviewerGrade() {
        return interviewerGrade;
    }

    public InterviewRound getRound() {
        return round;
    }

    public LocalDateTime getStartDateTime() {
        return startDateTime;
    }

    public LocalDateTime getEndDateTime() {
        return endDateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InterviewSlot that)) return false;
        return Objects.equals(slotId, that.slotId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(slotId);
    }

    @Override
    public String toString() {
        return "InterviewSlot{" +
                "slotId='" + slotId + '\'' +
                ", round=" + round +
                ", interviewerId='" + interviewerId + '\'' +
                ", grade=" + interviewerGrade +
                ", start=" + startDateTime +
                ", end=" + endDateTime +
                '}';
    }
}

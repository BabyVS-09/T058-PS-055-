package com.ats.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Sequential approval matrix container for an ATS candidate offer.
 */
public class ApprovalMatrix {
    private final String approvalId;
    private final String offerId;
    private final String applicationId;
    private final List<ApprovalStep> steps;
    private int currentStepIndex;
    private ApprovalStatus overallStatus;
    private final List<String> history;

    public ApprovalMatrix(String approvalId, String offerId, String applicationId, List<ApprovalStep> steps) {
        this.approvalId = approvalId;
        this.offerId = offerId;
        this.applicationId = applicationId;
        this.steps = new ArrayList<>(steps);
        this.currentStepIndex = 0;
        this.overallStatus = ApprovalStatus.PENDING;
        this.history = new ArrayList<>();
        this.history.add("Approval matrix initialized with " + steps.size() + " step(s) at " + LocalDateTime.now());
    }

    public String getApprovalId() {
        return approvalId;
    }

    public String getOfferId() {
        return offerId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public List<ApprovalStep> getSteps() {
        return Collections.unmodifiableList(steps);
    }

    public int getCurrentStepIndex() {
        return currentStepIndex;
    }

    public ApprovalStatus getOverallStatus() {
        return overallStatus;
    }

    public List<String> getHistory() {
        return Collections.unmodifiableList(history);
    }

    public ApprovalStep getCurrentStep() {
        if (currentStepIndex >= 0 && currentStepIndex < steps.size()) {
            return steps.get(currentStepIndex);
        }
        return null;
    }

    public synchronized boolean isFullyApproved() {
        return overallStatus == ApprovalStatus.APPROVED;
    }

    public synchronized boolean isRejected() {
        return overallStatus == ApprovalStatus.REJECTED;
    }

    /**
     * Records approval by a specific role.
     * Enforces sequential order. Rejection terminates chain.
     */
    public synchronized void recordDecision(ApprovalRole role, boolean approve, String remarks, LocalDateTime timestamp) {
        if (overallStatus != ApprovalStatus.PENDING) {
            throw new AtsException(ReasonCode.APPROVAL_ALREADY_DECIDED,
                    "Approval matrix is already in terminal state: " + overallStatus);
        }

        ApprovalStep current = getCurrentStep();
        if (current == null) {
            throw new AtsException(ReasonCode.APPROVAL_ALREADY_DECIDED, "No pending approval step.");
        }

        if (current.getRole() != role) {
            throw new AtsException(ReasonCode.APPROVAL_OUT_OF_ORDER,
                    "Expected approval from " + current.getRole() + " but received decision for " + role);
        }

        current.setActionTimestamp(timestamp);
        current.setRemarks(remarks);

        if (approve) {
            current.setStatus(ApprovalStatus.APPROVED);
            history.add("Step " + current.getStepNumber() + " approved by " + role + " (" + current.getApproverName() + ") at " + timestamp);
            currentStepIndex++;
            if (currentStepIndex >= steps.size()) {
                overallStatus = ApprovalStatus.APPROVED;
                history.add("Approval matrix fully APPROVED at " + timestamp);
            }
        } else {
            current.setStatus(ApprovalStatus.REJECTED);
            overallStatus = ApprovalStatus.REJECTED;
            history.add("Step " + current.getStepNumber() + " REJECTED by " + role + " (" + current.getApproverName() + ") at " + timestamp + ". Rejection terminates approval chain.");
        }
    }

    /**
     * Checks if current step has breached SLA (2 working days).
     * If timed out:
     * - Marks current step TIMED_OUT.
     * - If current role is VP or CFO, it is NEVER auto-skipped (BR-28). It remains waiting for VP/CFO.
     * - Otherwise escalates to next step.
     */
    public synchronized boolean evaluateSlaTimeout(LocalDate currentDate) {
        if (overallStatus != ApprovalStatus.PENDING) {
            return false;
        }

        ApprovalStep current = getCurrentStep();
        if (current == null || current.getStatus() != ApprovalStatus.PENDING) {
            return false;
        }

        if (currentDate.isAfter(current.getDeadlineDate())) {
            // SLA breached
            if (current.getRole() == ApprovalRole.VP || current.getRole() == ApprovalRole.CFO) {
                // Rule E: "Never automatically skip VP or CFO."
                history.add("Step " + current.getStepNumber() + " (" + current.getRole() + ") breached SLA on "
                        + currentDate + " (deadline " + current.getDeadlineDate() + "). SLA warning logged; VP/CFO cannot be auto-skipped.");
                return false;
            } else {
                current.setStatus(ApprovalStatus.TIMED_OUT);
                current.setActionTimestamp(currentDate.atStartOfDay());
                current.setRemarks("Auto escalated due to SLA timeout beyond " + current.getDeadlineDate());
                history.add("Step " + current.getStepNumber() + " (" + current.getRole() + ") TIMED_OUT on "
                        + currentDate + ". Escalating to next approver.");
                currentStepIndex++;
                if (currentStepIndex >= steps.size()) {
                    overallStatus = ApprovalStatus.APPROVED;
                    history.add("Approval matrix escalated through final step to APPROVED at " + currentDate);
                }
                return true;
            }
        }
        return false;
    }
}

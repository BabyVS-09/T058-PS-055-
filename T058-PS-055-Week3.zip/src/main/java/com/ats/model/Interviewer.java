package com.ats.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Interviewer entity participating in L1, L2, or HR panels.
 */
public class Interviewer {
    private final String interviewerId;
    private final String name;
    private final GradeBand gradeBand;
    private final LocalTime dailyWindowStart;
    private final LocalTime dailyWindowEnd;
    private final List<InterviewSlot> bookedSlots;

    public Interviewer(String interviewerId, String name, GradeBand gradeBand) {
        this(interviewerId, name, gradeBand, LocalTime.of(9, 0), LocalTime.of(18, 0));
    }

    public Interviewer(String interviewerId, String name, GradeBand gradeBand,
                       LocalTime dailyWindowStart, LocalTime dailyWindowEnd) {
        if (interviewerId == null || interviewerId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Interviewer ID cannot be null or empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Interviewer name cannot be null or empty.");
        }
        if (gradeBand == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Interviewer grade band cannot be null.");
        }

        this.interviewerId = interviewerId.trim();
        this.name = name.trim();
        this.gradeBand = gradeBand;
        this.dailyWindowStart = dailyWindowStart != null ? dailyWindowStart : LocalTime.of(9, 0);
        this.dailyWindowEnd = dailyWindowEnd != null ? dailyWindowEnd : LocalTime.of(18, 0);
        this.bookedSlots = new ArrayList<>();
    }

    public String getInterviewerId() {
        return interviewerId;
    }

    public String getName() {
        return name;
    }

    public GradeBand getGradeBand() {
        return gradeBand;
    }

    public LocalTime getDailyWindowStart() {
        return dailyWindowStart;
    }

    public LocalTime getDailyWindowEnd() {
        return dailyWindowEnd;
    }

    public synchronized List<InterviewSlot> getBookedSlots() {
        return Collections.unmodifiableList(new ArrayList<>(bookedSlots));
    }

    public synchronized int getInterviewCountOn(LocalDate date) {
        int count = 0;
        for (InterviewSlot slot : bookedSlots) {
            if (slot.getStartDateTime().toLocalDate().equals(date)) {
                count++;
            }
        }
        return count;
    }

    public synchronized boolean hasReachedDailyLimit(LocalDate date) {
        return getInterviewCountOn(date) >= 3;
    }

    /**
     * Checks if slot [start, end] can be booked without overlap and with at least minGapMinutes
     * before and after all existing interviews on that day.
     * Also checks that start and end fall within [dailyWindowStart, dailyWindowEnd].
     * DEC-03: Ending exactly at window boundary is valid.
     */
    public synchronized boolean isAvailable(LocalDateTime start, LocalDateTime end, int minGapMinutes) {
        LocalTime startTime = start.toLocalTime();
        LocalTime endTime = end.toLocalTime();

        // Must be within daily availability window
        if (startTime.isBefore(dailyWindowStart) || endTime.isAfter(dailyWindowEnd)) {
            return false;
        }

        // Daily limit of 3
        if (hasReachedDailyLimit(start.toLocalDate())) {
            return false;
        }

        for (InterviewSlot slot : bookedSlots) {
            if (!slot.getStartDateTime().toLocalDate().equals(start.toLocalDate())) {
                continue;
            }

            LocalDateTime existingStart = slot.getStartDateTime();
            LocalDateTime existingEnd = slot.getEndDateTime();

            // Direct overlap: (start < existingEnd) && (end > existingStart)
            if (start.isBefore(existingEnd) && end.isAfter(existingStart)) {
                return false;
            }

            // Gap check: if this interview is after existing interview, gap = start - existingEnd
            if (!start.isBefore(existingEnd)) {
                long gapMinutes = java.time.Duration.between(existingEnd, start).toMinutes();
                if (gapMinutes < minGapMinutes) {
                    return false;
                }
            }

            // Gap check: if this interview is before existing interview, gap = existingStart - end
            if (!end.isAfter(existingStart)) {
                long gapMinutes = java.time.Duration.between(end, existingStart).toMinutes();
                if (gapMinutes < minGapMinutes) {
                    return false;
                }
            }
        }

        return true;
    }

    public synchronized void bookSlot(InterviewSlot slot) {
        this.bookedSlots.add(slot);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Interviewer that)) return false;
        return Objects.equals(interviewerId, that.interviewerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(interviewerId);
    }

    @Override
    public String toString() {
        return "Interviewer{" +
                "interviewerId='" + interviewerId + '\'' +
                ", name='" + name + '\'' +
                ", gradeBand=" + gradeBand +
                ", bookedCount=" + bookedSlots.size() +
                '}';
    }
}

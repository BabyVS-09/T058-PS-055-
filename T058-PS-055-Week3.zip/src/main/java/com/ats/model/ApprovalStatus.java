package com.ats.model;

/**
 * Status of an approval step or overall approval matrix.
 */
public enum ApprovalStatus {
    PENDING,
    APPROVED,
    REJECTED,
    TIMED_OUT;

    public static ApprovalStatus from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("ApprovalStatus cannot be null or empty.");
        }
        return ApprovalStatus.valueOf(value.trim().toUpperCase());
    }
}

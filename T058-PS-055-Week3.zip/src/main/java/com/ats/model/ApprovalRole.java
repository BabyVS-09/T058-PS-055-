package com.ats.model;

/**
 * Roles responsible for approving candidate offers in the Approval Matrix.
 */
public enum ApprovalRole {
    HIRING_MANAGER,
    HR_HEAD,
    VP,
    CFO;

    public static ApprovalRole from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("ApprovalRole cannot be null or empty.");
        }
        return ApprovalRole.valueOf(value.trim().toUpperCase());
    }
}

package com.ats.model;

/**
 * Result returned by stage transition operations.
 */
public record TransitionResult(
        boolean success,
        CandidateStage fromStage,
        CandidateStage toStage,
        ReasonCode reasonCode,
        String message
) {
    public static TransitionResult success(CandidateStage fromStage, CandidateStage toStage, String message) {
        return new TransitionResult(true, fromStage, toStage, ReasonCode.SUCCESS, message);
    }

    public static TransitionResult failure(CandidateStage fromStage, CandidateStage toStage, ReasonCode reasonCode, String message) {
        return new TransitionResult(false, fromStage, toStage, reasonCode, message);
    }
}

package com.ats.model;

/**
 * Result returned by InterviewScheduler.
 */
public record InterviewSchedulingResult(
        boolean success,
        InterviewSlot bookedSlot,
        ReasonCode reasonCode,
        String message
) {
    public static InterviewSchedulingResult success(InterviewSlot slot, String message) {
        return new InterviewSchedulingResult(true, slot, ReasonCode.SUCCESS, message);
    }

    public static InterviewSchedulingResult failure(ReasonCode reasonCode, String message) {
        return new InterviewSchedulingResult(false, null, reasonCode, message);
    }
}

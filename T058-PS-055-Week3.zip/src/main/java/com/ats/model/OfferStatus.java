package com.ats.model;

/**
 * Lifecycle status of an offer.
 */
public enum OfferStatus {
    DRAFT,
    PENDING_APPROVAL,
    APPROVED,
    OFFERED,
    ACCEPTED,
    DECLINED,
    EXPIRED,
    WITHDRAWN;

    public static OfferStatus from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("OfferStatus cannot be null or empty.");
        }
        return OfferStatus.valueOf(value.trim().toUpperCase());
    }
}

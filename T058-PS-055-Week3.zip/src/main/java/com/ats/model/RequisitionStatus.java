package com.ats.model;

/**
 * Lifecycle status of a job requisition.
 */
public enum RequisitionStatus {
    OPEN,
    AT_RISK,
    CLOSED;

    public static RequisitionStatus from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("RequisitionStatus cannot be null or empty.");
        }
        return RequisitionStatus.valueOf(value.trim().toUpperCase());
    }
}

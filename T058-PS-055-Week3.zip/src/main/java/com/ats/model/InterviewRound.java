package com.ats.model;

/**
 * Interview rounds in PS-055 ATS pipeline.
 * L1 duration: 60 minutes.
 * L2 duration: 45 minutes.
 * HR duration: 30 minutes.
 */
public enum InterviewRound {
    L1(60, 3.0),
    L2(45, 3.5),
    HR(30, 0.0);

    private final int defaultDurationMinutes;
    private final double passingScoreThreshold;

    InterviewRound(int defaultDurationMinutes, double passingScoreThreshold) {
        this.defaultDurationMinutes = defaultDurationMinutes;
        this.passingScoreThreshold = passingScoreThreshold;
    }

    public int getDefaultDurationMinutes() {
        return defaultDurationMinutes;
    }

    public double getPassingScoreThreshold() {
        return passingScoreThreshold;
    }

    public static InterviewRound from(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("InterviewRound cannot be null or empty.");
        }
        return InterviewRound.valueOf(value.trim().toUpperCase());
    }
}

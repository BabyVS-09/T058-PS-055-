package com.ats.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;

/**
 * Application entity representing a candidate applying to a requisition.
 */
public class Application {
    private final String applicationId;
    private final String candidateId;
    private final String requisitionId;
    private final GradeBand targetGrade;
    private final LocalDate applicationDate;
    private CandidateStage currentStage;
    private final Map<InterviewRound, BigDecimal> scores;
    private final List<StageTransitionRecord> stageHistory;
    private final List<InterviewSlot> interviewSlots;
    private Offer offer;
    private Integer waitlistRank;

    public Application(String applicationId, String candidateId, String requisitionId,
                       GradeBand targetGrade, LocalDate applicationDate) {
        if (applicationId == null || applicationId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Application ID cannot be null or empty.");
        }
        if (candidateId == null || candidateId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Candidate ID cannot be null or empty.");
        }
        if (requisitionId == null || requisitionId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Requisition ID cannot be null or empty.");
        }
        if (targetGrade == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Target grade cannot be null.");
        }
        if (applicationDate == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Application date cannot be null.");
        }

        this.applicationId = applicationId.trim();
        this.candidateId = candidateId.trim();
        this.requisitionId = requisitionId.trim();
        this.targetGrade = targetGrade;
        this.applicationDate = applicationDate;
        this.currentStage = CandidateStage.SCREENED;
        this.scores = new EnumMap<>(InterviewRound.class);
        this.stageHistory = new ArrayList<>();
        this.interviewSlots = new ArrayList<>();
        this.stageHistory.add(new StageTransitionRecord(null, CandidateStage.SCREENED, ReasonCode.SUCCESS, "Application initialized in SCREENED stage"));
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getCandidateId() {
        return candidateId;
    }

    public String getRequisitionId() {
        return requisitionId;
    }

    public GradeBand getTargetGrade() {
        return targetGrade;
    }

    public LocalDate getApplicationDate() {
        return applicationDate;
    }

    public synchronized CandidateStage getCurrentStage() {
        return currentStage;
    }

    public synchronized void setCurrentStage(CandidateStage currentStage) {
        this.currentStage = currentStage;
    }

    public synchronized Map<InterviewRound, BigDecimal> getScores() {
        return Collections.unmodifiableMap(new EnumMap<>(scores));
    }

    public synchronized BigDecimal getScore(InterviewRound round) {
        return scores.get(round);
    }

    public synchronized void recordScore(InterviewRound round, BigDecimal score) {
        if (round == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Interview round cannot be null.");
        }
        if (score == null || score.compareTo(BigDecimal.ZERO) < 0 || score.compareTo(BigDecimal.valueOf(5.0)) > 0) {
            throw new AtsException(ReasonCode.INVALID_SCORE, "Score must be strictly within 0.0 to 5.0 range.");
        }
        scores.put(round, score.setScale(2, RoundingMode.HALF_UP));
    }

    public synchronized List<StageTransitionRecord> getStageHistory() {
        return Collections.unmodifiableList(new ArrayList<>(stageHistory));
    }

    public synchronized void addStageTransition(StageTransitionRecord record) {
        this.stageHistory.add(record);
        this.currentStage = record.toStage();
    }

    public synchronized List<InterviewSlot> getInterviewSlots() {
        return Collections.unmodifiableList(new ArrayList<>(interviewSlots));
    }

    public synchronized void addInterviewSlot(InterviewSlot slot) {
        this.interviewSlots.add(slot);
    }

    public synchronized Offer getOffer() {
        return offer;
    }

    public synchronized void setOffer(Offer offer) {
        this.offer = offer;
    }

    public synchronized Integer getWaitlistRank() {
        return waitlistRank;
    }

    public synchronized void setWaitlistRank(Integer waitlistRank) {
        this.waitlistRank = waitlistRank;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Application that)) return false;
        return Objects.equals(applicationId, that.applicationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(applicationId);
    }

    @Override
    public String toString() {
        return "Application{" +
                "applicationId='" + applicationId + '\'' +
                ", candidateId='" + candidateId + '\'' +
                ", requisitionId='" + requisitionId + '\'' +
                ", currentStage=" + currentStage +
                ", targetGrade=" + targetGrade +
                '}';
    }
}

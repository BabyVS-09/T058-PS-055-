package com.ats.model;

import java.math.BigDecimal;

/**
 * Encapsulates calculation results for compensation, bonuses, fees, and approval flags.
 */
public record OfferCalculationResult(
        BigDecimal expectedCtc,
        BigDecimal offeredCtc,
        BigDecimal joiningBonus,
        BigDecimal buyoutReimbursement,
        BigDecimal recruitmentFee,
        BigDecimal totalCost,
        boolean outOfBand,
        boolean requiresVpApproval,
        boolean requiresCfoApproval,
        String breakdownDetails
) {}

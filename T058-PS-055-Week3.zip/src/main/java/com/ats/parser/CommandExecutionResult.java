package com.ats.parser;

import com.ats.model.ReasonCode;

/**
 * Result of parsing and executing an individual command line.
 */
public record CommandExecutionResult(
        int lineNumber,
        String rawLine,
        String command,
        boolean success,
        ReasonCode reasonCode,
        String message
) {
    public static CommandExecutionResult success(int lineNumber, String rawLine, String command, String message) {
        return new CommandExecutionResult(lineNumber, rawLine, command, true, ReasonCode.SUCCESS, message);
    }

    public static CommandExecutionResult failure(int lineNumber, String rawLine, String command, ReasonCode reasonCode, String message) {
        return new CommandExecutionResult(lineNumber, rawLine, command, false, reasonCode, message);
    }
}

package com.ats.parser;

import com.ats.model.*;
import com.ats.service.RecruitmentService;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Pipe-delimited command file parser and execution engine.
 * Supports all Week 2 commands and Week 3 extensions:
 * - REGISTER_REQUISITION
 * - REGISTER_CANDIDATE
 * - APPLY
 * - SCHEDULE_INTERVIEW
 * - RECORD_SCORE
 * - DRAFT_OFFER
 * - REQUEST_APPROVAL
 * - RECORD_APPROVAL
 * - ACCEPT_OFFER
 * - DECLINE_OFFER
 * - EXPIRE_OFFER
 * - RELEASE_HEADCOUNT
 * - TRANSITION_STAGE
 * - SUMMARY
 */
public class CommandFileParser {

    private final RecruitmentService recruitmentService;

    public CommandFileParser(RecruitmentService recruitmentService) {
        this.recruitmentService = recruitmentService;
    }

    public List<CommandExecutionResult> parseAndExecute(File file) throws IOException {
        List<CommandExecutionResult> results = new ArrayList<>();
        if (!file.exists()) {
            throw new IOException("Command file not found: " + file.getAbsolutePath());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    continue; // skip blank lines and comments
                }

                CommandExecutionResult result = executeLine(lineNumber, trimmed);
                results.add(result);

                // Print console output
                if (result.success()) {
                    System.out.println("[SUCCESS] " + result.message());
                } else {
                    System.out.println("[ERROR] Line " + result.lineNumber() + " [" + result.reasonCode() + "]: " + result.message());
                }
            }
        }
        return results;
    }

    public CommandExecutionResult executeLine(int lineNumber, String line) {
        String[] parts = line.split("\\|");
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }

        if (parts.length == 0 || parts[0].isEmpty()) {
            return CommandExecutionResult.failure(lineNumber, line, "EMPTY", ReasonCode.UNKNOWN_COMMAND, "Empty command line.");
        }

        String command = parts[0].toUpperCase();

        try {
            return switch (command) {
                case "REGISTER_REQUISITION" -> handleRegisterRequisition(lineNumber, line, parts);
                case "REGISTER_CANDIDATE" -> handleRegisterCandidate(lineNumber, line, parts);
                case "APPLY" -> handleApply(lineNumber, line, parts);
                case "SCHEDULE_INTERVIEW" -> handleScheduleInterview(lineNumber, line, parts);
                case "RECORD_SCORE" -> handleRecordScore(lineNumber, line, parts);
                case "DRAFT_OFFER" -> handleDraftOffer(lineNumber, line, parts);
                case "REQUEST_APPROVAL" -> handleRequestApproval(lineNumber, line, parts);
                case "RECORD_APPROVAL" -> handleRecordApproval(lineNumber, line, parts);
                case "ACCEPT_OFFER" -> handleAcceptOffer(lineNumber, line, parts);
                case "DECLINE_OFFER" -> handleDeclineOffer(lineNumber, line, parts);
                case "EXPIRE_OFFER" -> handleExpireOffer(lineNumber, line, parts);
                case "RELEASE_HEADCOUNT" -> handleReleaseHeadcount(lineNumber, line, parts);
                case "TRANSITION_STAGE" -> handleTransitionStage(lineNumber, line, parts);
                case "SUMMARY" -> handleSummary(lineNumber, line);
                default -> CommandExecutionResult.failure(lineNumber, line, command, ReasonCode.UNKNOWN_COMMAND, "Unknown command: " + command);
            };
        } catch (AtsException e) {
            return CommandExecutionResult.failure(lineNumber, line, command, e.getReasonCode(), e.getMessage());
        } catch (Exception e) {
            return CommandExecutionResult.failure(lineNumber, line, command, ReasonCode.PARSER_ERROR, "Unexpected error: " + e.getMessage());
        }
    }

    private CommandExecutionResult handleRegisterRequisition(int lineNum, String line, String[] parts) {
        // REGISTER_REQUISITION | <reqId> | <role> | <G1..G6> | <headcount> | <location> | <minCtc> | <maxCtc> | <hiringManager> | <YYYY-MM-DD>
        if (parts.length < 10) {
            return CommandExecutionResult.failure(lineNum, line, "REGISTER_REQUISITION", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected 10 fields for REGISTER_REQUISITION, got " + parts.length);
        }
        String reqId = parts[1];
        String role = parts[2];
        GradeBand grade = GradeBand.from(parts[3]);
        int headcount = Integer.parseInt(parts[4]);
        String location = parts[5];
        BigDecimal minCtc = new BigDecimal(parts[6]);
        BigDecimal maxCtc = new BigDecimal(parts[7]);
        String hm = parts[8];
        LocalDate opened = LocalDate.parse(parts[9]);

        Requisition req = recruitmentService.registerRequisition(reqId, role, grade, headcount, location, minCtc, maxCtc, hm, opened);
        return CommandExecutionResult.success(lineNum, line, "REGISTER_REQUISITION",
                "Requisition registered: ID=" + req.getRequisitionId() + ", Role=\"" + req.getRole()
                        + "\", Grade=" + req.getGradeBand() + ", Headcount=" + req.getHeadcount()
                        + ", Location=" + req.getLocation() + ", CTC=" + req.getMinCtc() + "-" + req.getMaxCtc()
                        + ", Manager=\"" + req.getHiringManager() + "\", Opened=" + req.getOpenedDate());
    }

    private CommandExecutionResult handleRegisterCandidate(int lineNum, String line, String[] parts) {
        // REGISTER_CANDIDATE | <candidateId> | <name> | <noticeDays> | <currentCtc> | <expectedCtc> | <expYears> | <REFERRAL|PORTAL|AGENCY|INTERNAL>
        if (parts.length < 8) {
            return CommandExecutionResult.failure(lineNum, line, "REGISTER_CANDIDATE", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected 8 fields for REGISTER_CANDIDATE, got " + parts.length);
        }
        String id = parts[1];
        String name = parts[2];
        int notice = Integer.parseInt(parts[3]);
        BigDecimal current = new BigDecimal(parts[4]);
        BigDecimal expected = new BigDecimal(parts[5]);
        BigDecimal exp = new BigDecimal(parts[6]);
        CandidateSource source = CandidateSource.from(parts[7]);

        Candidate can = recruitmentService.registerCandidate(id, name, notice, current, expected, exp, source);
        return CommandExecutionResult.success(lineNum, line, "REGISTER_CANDIDATE",
                "Candidate registered: ID=" + can.getCandidateId() + ", Name=\"" + can.getName()
                        + "\", NoticeDays=" + can.getNoticePeriodDays() + ", CurrentCTC=" + can.getCurrentCtc()
                        + ", ExpectedCTC=" + can.getExpectedCtc() + ", Experience=" + can.getExperienceYears()
                        + " yrs, Source=" + can.getSource());
    }

    private CommandExecutionResult handleApply(int lineNum, String line, String[] parts) {
        // APPLY | <applicationId> | <candidateId> | <requisitionId> | <YYYY-MM-DD>
        if (parts.length < 5) {
            return CommandExecutionResult.failure(lineNum, line, "APPLY", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected 5 fields for APPLY, got " + parts.length);
        }
        String appId = parts[1];
        String canId = parts[2];
        String reqId = parts[3];
        LocalDate applied = LocalDate.parse(parts[4]);

        Application app = recruitmentService.apply(appId, canId, reqId, applied);
        Candidate can = recruitmentService.getCandidate(canId);
        Requisition req = recruitmentService.getRequisition(reqId);
        return CommandExecutionResult.success(lineNum, line, "APPLY",
                "Application created: ID=" + app.getApplicationId() + ", Candidate=" + canId
                        + " (\"" + (can != null ? can.getName() : "") + "\"), Requisition=" + reqId
                        + " (\"" + (req != null ? req.getRole() : "") + "\"), TargetGrade=" + app.getTargetGrade()
                        + ", Stage=" + app.getCurrentStage() + ", AppliedOn=" + app.getApplicationDate());
    }

    private CommandExecutionResult handleScheduleInterview(int lineNum, String line, String[] parts) {
        // SCHEDULE_INTERVIEW | <applicationId> | <L1|L2|HR> | <optional YYYY-MM-DD>
        if (parts.length < 3) {
            return CommandExecutionResult.failure(lineNum, line, "SCHEDULE_INTERVIEW", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 3 fields for SCHEDULE_INTERVIEW");
        }
        String appId = parts[1];
        InterviewRound round = InterviewRound.from(parts[2]);
        LocalDate fromDate = (parts.length > 3 && !parts[3].isEmpty()) ? LocalDate.parse(parts[3]) : null;

        InterviewSchedulingResult res = recruitmentService.scheduleInterview(appId, round, fromDate);
        if (res.success()) {
            return CommandExecutionResult.success(lineNum, line, "SCHEDULE_INTERVIEW", res.message());
        } else {
            return CommandExecutionResult.failure(lineNum, line, "SCHEDULE_INTERVIEW", res.reasonCode(), res.message());
        }
    }

    private CommandExecutionResult handleRecordScore(int lineNum, String line, String[] parts) {
        // RECORD_SCORE | <applicationId> | <L1|L2|HR> | <0.0..5.0>
        if (parts.length < 4) {
            return CommandExecutionResult.failure(lineNum, line, "RECORD_SCORE", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected 4 fields for RECORD_SCORE");
        }
        String appId = parts[1];
        InterviewRound round = InterviewRound.from(parts[2]);
        BigDecimal score = new BigDecimal(parts[3]);

        TransitionResult res = recruitmentService.recordScore(appId, round, score);
        if (res.success()) {
            return CommandExecutionResult.success(lineNum, line, "RECORD_SCORE",
                    round + " score " + score + " recorded for application " + appId + ".");
        } else {
            return CommandExecutionResult.failure(lineNum, line, "RECORD_SCORE", res.reasonCode(), res.message());
        }
    }

    private CommandExecutionResult handleDraftOffer(int lineNum, String line, String[] parts) {
        // DRAFT_OFFER | <offerId> | <applicationId> | <offerDate> | <targetJoiningDate> | <buyout: true/false> | <optional buyoutAmount>
        if (parts.length < 6) {
            return CommandExecutionResult.failure(lineNum, line, "DRAFT_OFFER", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 6 fields for DRAFT_OFFER");
        }
        String offerId = parts[1];
        String appId = parts[2];
        LocalDate offerDate = LocalDate.parse(parts[3]);
        LocalDate targetJoining = LocalDate.parse(parts[4]);
        boolean buyout = Boolean.parseBoolean(parts[5]);
        BigDecimal buyoutAmount = (parts.length > 6 && !parts[6].isEmpty()) ? new BigDecimal(parts[6]) : null;

        Offer offer = recruitmentService.draftOffer(offerId, appId, offerDate, targetJoining, buyout, buyoutAmount);
        return CommandExecutionResult.success(lineNum, line, "DRAFT_OFFER",
                "Offer drafted: ID=" + offer.getOfferId() + ", Application=" + appId
                        + ", OfferedCTC=" + offer.getOfferedCtc() + ", Bonus=" + offer.getJoiningBonus()
                        + ", TotalCost=" + offer.getTotalCost() + ", OutOfBand=" + offer.isOutOfBand());
    }

    private CommandExecutionResult handleRequestApproval(int lineNum, String line, String[] parts) {
        // REQUEST_APPROVAL | <approvalId> | <offerId> | <optional requestDate>
        if (parts.length < 3) {
            return CommandExecutionResult.failure(lineNum, line, "REQUEST_APPROVAL", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 3 fields for REQUEST_APPROVAL");
        }
        String approvalId = parts[1];
        String offerId = parts[2];
        LocalDate reqDate = (parts.length > 3 && !parts[3].isEmpty()) ? LocalDate.parse(parts[3]) : null;

        ApprovalMatrix matrix = recruitmentService.requestApproval(approvalId, offerId, reqDate);
        return CommandExecutionResult.success(lineNum, line, "REQUEST_APPROVAL",
                "Approval requested: ID=" + matrix.getApprovalId() + ", Steps=" + matrix.getSteps().size()
                        + ", FirstApprover=" + (matrix.getCurrentStep() != null ? matrix.getCurrentStep().getRole() : "None"));
    }

    private CommandExecutionResult handleRecordApproval(int lineNum, String line, String[] parts) {
        // RECORD_APPROVAL | <approvalId> | <role> | <APPROVE|REJECT> | <remarks>
        if (parts.length < 4) {
            return CommandExecutionResult.failure(lineNum, line, "RECORD_APPROVAL", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 4 fields for RECORD_APPROVAL");
        }
        String approvalId = parts[1];
        ApprovalRole role = ApprovalRole.from(parts[2]);
        boolean approve = "APPROVE".equalsIgnoreCase(parts[3]) || "APPROVED".equalsIgnoreCase(parts[3]);
        String remarks = (parts.length > 4) ? parts[4] : "";

        recruitmentService.recordApproval(approvalId, role, approve, remarks, LocalDateTime.now());
        ApprovalMatrix matrix = recruitmentService.getApprovalMatrix(approvalId);
        return CommandExecutionResult.success(lineNum, line, "RECORD_APPROVAL",
                "Approval recorded for " + role + " on matrix " + approvalId + ". OverallStatus=" + matrix.getOverallStatus());
    }

    private CommandExecutionResult handleAcceptOffer(int lineNum, String line, String[] parts) {
        // ACCEPT_OFFER | <applicationId> | <optional LocalDateTime>
        if (parts.length < 2) {
            return CommandExecutionResult.failure(lineNum, line, "ACCEPT_OFFER", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 2 fields for ACCEPT_OFFER");
        }
        String appId = parts[1];
        LocalDateTime acceptTime = null;
        if (parts.length > 2 && !parts[2].isEmpty()) {
            try {
                acceptTime = LocalDateTime.parse(parts[2]);
            } catch (DateTimeParseException e) {
                acceptTime = LocalDate.parse(parts[2]).atTime(12, 0);
            }
        }

        TransitionResult res = recruitmentService.acceptOffer(appId, acceptTime);
        if (res.success()) {
            return CommandExecutionResult.success(lineNum, line, "ACCEPT_OFFER", res.message());
        } else {
            return CommandExecutionResult.failure(lineNum, line, "ACCEPT_OFFER", res.reasonCode(), res.message());
        }
    }

    private CommandExecutionResult handleDeclineOffer(int lineNum, String line, String[] parts) {
        // DECLINE_OFFER | <applicationId> | <reason>
        if (parts.length < 2) {
            return CommandExecutionResult.failure(lineNum, line, "DECLINE_OFFER", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 2 fields for DECLINE_OFFER");
        }
        String appId = parts[1];
        String reason = (parts.length > 2) ? parts[2] : "Candidate declined";

        TransitionResult res = recruitmentService.declineOffer(appId, reason);
        return CommandExecutionResult.success(lineNum, line, "DECLINE_OFFER", res.message());
    }

    private CommandExecutionResult handleExpireOffer(int lineNum, String line, String[] parts) {
        // EXPIRE_OFFER | <applicationId> | <currentDateTime>
        if (parts.length < 2) {
            return CommandExecutionResult.failure(lineNum, line, "EXPIRE_OFFER", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected at least 2 fields for EXPIRE_OFFER");
        }
        String appId = parts[1];
        LocalDateTime now = (parts.length > 2 && !parts[2].isEmpty()) ? LocalDateTime.parse(parts[2]) : null;

        TransitionResult res = recruitmentService.expireOffer(appId, now);
        if (res.success()) {
            return CommandExecutionResult.success(lineNum, line, "EXPIRE_OFFER", res.message());
        } else {
            return CommandExecutionResult.failure(lineNum, line, "EXPIRE_OFFER", res.reasonCode(), res.message());
        }
    }

    private CommandExecutionResult handleReleaseHeadcount(int lineNum, String line, String[] parts) {
        // RELEASE_HEADCOUNT | <requisitionId>
        if (parts.length < 2) {
            return CommandExecutionResult.failure(lineNum, line, "RELEASE_HEADCOUNT", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected requisitionId for RELEASE_HEADCOUNT");
        }
        String reqId = parts[1];
        boolean released = recruitmentService.releaseHeadcount(reqId);
        if (released) {
            return CommandExecutionResult.success(lineNum, line, "RELEASE_HEADCOUNT", "Headcount released for requisition " + reqId);
        } else {
            return CommandExecutionResult.failure(lineNum, line, "RELEASE_HEADCOUNT", ReasonCode.HEADCOUNT_EXHAUSTED,
                    "No reserved headcount to release for requisition " + reqId);
        }
    }

    private CommandExecutionResult handleTransitionStage(int lineNum, String line, String[] parts) {
        // TRANSITION_STAGE | <applicationId> | <targetStage>
        if (parts.length < 3) {
            return CommandExecutionResult.failure(lineNum, line, "TRANSITION_STAGE", ReasonCode.MISSING_REQUIRED_FIELD,
                    "Expected 3 fields for TRANSITION_STAGE");
        }
        String appId = parts[1];
        CandidateStage target = CandidateStage.from(parts[2]);

        TransitionResult res = recruitmentService.transitionStage(appId, target);
        if (res.success()) {
            return CommandExecutionResult.success(lineNum, line, "TRANSITION_STAGE", res.message());
        } else {
            return CommandExecutionResult.failure(lineNum, line, "TRANSITION_STAGE", res.reasonCode(), res.message());
        }
    }

    private CommandExecutionResult handleSummary(int lineNum, String line) {
        String summary = recruitmentService.getSummary();
        System.out.println(summary);
        return CommandExecutionResult.success(lineNum, line, "SUMMARY", "Pipeline summary displayed.");
    }
}

package com.ats.service;

import com.ats.model.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

/**
 * Interview scheduling engine implementing Week 3 Module A requirements:
 * - L1 duration: 60 minutes
 * - L2 duration: 45 minutes
 * - HR duration: 30 minutes
 * - Maximum three interviews per interviewer per day
 * - Minimum 15-minute gap between interviews
 * - No overlapping interviews
 * - L2 panel must include an interviewer at least one grade higher than candidate's target grade
 * - Find earliest valid slot in next 10 working days
 * - Exclude weekends and supplied holidays
 * - Return NO_SLOT if no slot available
 * - Do not change candidate stage if scheduling fails
 * - Interview ending exactly at availability-window boundary is valid
 */
public class InterviewScheduler {
    public static final int MIN_GAP_MINUTES = 15;
    public static final int MAX_WORKING_DAYS = 10;
    public static final LocalTime DEFAULT_WINDOW_START = LocalTime.of(9, 0);
    public static final LocalTime DEFAULT_WINDOW_END = LocalTime.of(18, 0);

    private final List<Interviewer> interviewers;
    private final Set<LocalDate> holidays;

    public InterviewScheduler() {
        this(new ArrayList<>(), new HashSet<>());
    }

    public InterviewScheduler(List<Interviewer> interviewers, Set<LocalDate> holidays) {
        this.interviewers = new ArrayList<>(interviewers);
        this.holidays = new HashSet<>(holidays != null ? holidays : Collections.emptySet());
    }

    public synchronized void registerInterviewer(Interviewer interviewer) {
        if (interviewer != null && !interviewers.contains(interviewer)) {
            interviewers.add(interviewer);
        }
    }

    public synchronized void addHoliday(LocalDate holiday) {
        if (holiday != null) {
            holidays.add(holiday);
        }
    }

    public synchronized void addHolidays(Collection<LocalDate> holidays) {
        if (holidays != null) {
            this.holidays.addAll(holidays);
        }
    }

    public boolean isWorkingDay(LocalDate date) {
        DayOfWeek dow = date.getDayOfWeek();
        if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
            return false;
        }
        return !holidays.contains(date);
    }

    /**
     * Computes the next 10 working days strictly after or starting on startDate.
     */
    public List<LocalDate> getNextWorkingDays(LocalDate startDate, int count) {
        List<LocalDate> workingDays = new ArrayList<>();
        LocalDate curr = startDate;
        while (workingDays.size() < count) {
            if (isWorkingDay(curr)) {
                workingDays.add(curr);
            }
            curr = curr.plusDays(1);
        }
        return workingDays;
    }

    /**
     * Schedules an interview slot for an application and round.
     *
     * @param application the application being scheduled
     * @param round L1, L2, or HR
     * @param fromDate date from which to start searching (usually candidate stage transition date or today)
     * @return InterviewSchedulingResult
     */
    public synchronized InterviewSchedulingResult scheduleInterview(Application application,
                                                                    InterviewRound round,
                                                                    LocalDate fromDate) {
        if (application == null) {
            return InterviewSchedulingResult.failure(ReasonCode.APPLICATION_NOT_FOUND, "Application cannot be null.");
        }
        if (round == null) {
            return InterviewSchedulingResult.failure(ReasonCode.INVALID_INTERVIEW_ROUND, "Interview round cannot be null.");
        }

        int durationMinutes = round.getDefaultDurationMinutes();
        GradeBand targetGrade = application.getTargetGrade();

        // Filter interviewers eligible for this round
        List<Interviewer> eligibleInterviewers = new ArrayList<>();
        for (Interviewer interviewer : interviewers) {
            if (round == InterviewRound.L2) {
                // Rule A: L2 panel must include an interviewer at least one grade higher than target grade
                if (interviewer.getGradeBand().isAtLeastOneGradeHigherThan(targetGrade)) {
                    eligibleInterviewers.add(interviewer);
                }
            } else {
                eligibleInterviewers.add(interviewer);
            }
        }

        if (eligibleInterviewers.isEmpty()) {
            if (round == InterviewRound.L2) {
                return InterviewSchedulingResult.failure(ReasonCode.PANEL_GRADE_INSUFFICIENT,
                        "No interviewer available with grade at least one higher than target grade " + targetGrade);
            } else {
                return InterviewSchedulingResult.failure(ReasonCode.NO_SLOT, "No interviewers registered.");
            }
        }

        // Get next 10 working days
        List<LocalDate> searchDays = getNextWorkingDays(fromDate, MAX_WORKING_DAYS);

        // Search day by day, time by time
        for (LocalDate day : searchDays) {
            LocalTime windowStart = DEFAULT_WINDOW_START;
            LocalTime windowEnd = DEFAULT_WINDOW_END;

            // Step in 15-minute intervals
            LocalTime slotStart = windowStart;
            while (!slotStart.plusMinutes(durationMinutes).isAfter(windowEnd)) {
                LocalTime slotEnd = slotStart.plusMinutes(durationMinutes);
                LocalDateTime startDt = LocalDateTime.of(day, slotStart);
                LocalDateTime endDt = LocalDateTime.of(day, slotEnd);

                for (Interviewer interviewer : eligibleInterviewers) {
                    if (interviewer.isAvailable(startDt, endDt, MIN_GAP_MINUTES)) {
                        // Slot found!
                        String slotId = "SLOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
                        InterviewSlot bookedSlot = new InterviewSlot(
                                slotId,
                                application.getApplicationId(),
                                application.getCandidateId(),
                                interviewer.getInterviewerId(),
                                interviewer.getGradeBand(),
                                round,
                                startDt,
                                endDt
                        );

                        interviewer.bookSlot(bookedSlot);
                        application.addInterviewSlot(bookedSlot);

                        return InterviewSchedulingResult.success(bookedSlot,
                                "Successfully scheduled " + round + " interview with " + interviewer.getName()
                                        + " (" + interviewer.getGradeBand() + ") on " + startDt + " to " + endDt);
                    }
                }

                slotStart = slotStart.plusMinutes(MIN_GAP_MINUTES);
            }
        }

        // Rule A: Return NO_SLOT if no slot is available. Do not change candidate stage.
        return InterviewSchedulingResult.failure(ReasonCode.NO_SLOT,
                "No valid slot found within next 10 working days for round " + round);
    }
}

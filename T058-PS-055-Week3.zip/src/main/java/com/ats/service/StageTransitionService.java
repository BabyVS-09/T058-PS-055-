package com.ats.service;

import com.ats.model.*;

import java.math.BigDecimal;
import java.util.*;

/**
 * State machine managing the 14 application stages, transition gates, score validations,
 * and headcount hooks.
 */
public class StageTransitionService {

    private final boolean enforceMandatoryScores;

    public StageTransitionService() {
        this(false);
    }

    public StageTransitionService(boolean enforceMandatoryScores) {
        this.enforceMandatoryScores = enforceMandatoryScores;
    }

    public boolean isEnforceMandatoryScores() {
        return enforceMandatoryScores;
    }

    /**
     * Set of allowed forward or branch transitions from each stage.
     */
    public Set<CandidateStage> getAllowedNextStages(CandidateStage fromStage) {
        if (fromStage == null) {
            return Collections.singleton(CandidateStage.SCREENED);
        }
        return switch (fromStage) {
            case SCREENED -> EnumSet.of(CandidateStage.L1, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WITHDRAWN);
            case L1 -> EnumSet.of(CandidateStage.L2, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WITHDRAWN);
            case L2 -> EnumSet.of(CandidateStage.HR, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WAITLIST, CandidateStage.WITHDRAWN);
            case HR -> EnumSet.of(CandidateStage.OFFER_DRAFT, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WAITLIST, CandidateStage.WITHDRAWN);
            case OFFER_DRAFT -> EnumSet.of(CandidateStage.OFFER_APPROVED, CandidateStage.DECLINED, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WITHDRAWN);
            case OFFER_APPROVED -> EnumSet.of(CandidateStage.OFFERED, CandidateStage.DECLINED, CandidateStage.REJECTED, CandidateStage.ON_HOLD, CandidateStage.WITHDRAWN);
            case OFFERED -> EnumSet.of(CandidateStage.ACCEPTED, CandidateStage.DECLINED, CandidateStage.WITHDRAWN, CandidateStage.ON_HOLD);
            case ACCEPTED -> EnumSet.of(CandidateStage.JOINED, CandidateStage.DECLINED, CandidateStage.WITHDRAWN);
            case WAITLIST -> EnumSet.of(CandidateStage.OFFER_DRAFT, CandidateStage.REJECTED, CandidateStage.WITHDRAWN, CandidateStage.ON_HOLD);
            case ON_HOLD -> EnumSet.of(CandidateStage.SCREENED, CandidateStage.L1, CandidateStage.L2, CandidateStage.HR, CandidateStage.OFFER_DRAFT, CandidateStage.REJECTED, CandidateStage.WITHDRAWN);
            case JOINED, REJECTED, DECLINED, WITHDRAWN -> Collections.emptySet(); // Terminal stages
        };
    }

    /**
     * Validates and records interview score.
     * Enforces Module B:
     * - Score must be strictly within 0.0 to 5.0.
     * - Auto-rejects candidate if score < 2.0.
     * - Flags insufficient score if L1 < 3.0 or L2 < 3.5.
     */
    public synchronized TransitionResult recordScore(Application application, InterviewRound round, BigDecimal score) {
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application cannot be null.");
        }
        if (round == null) {
            throw new AtsException(ReasonCode.INVALID_INTERVIEW_ROUND, "Interview round cannot be null.");
        }
        if (score == null || score.compareTo(BigDecimal.ZERO) < 0 || score.compareTo(BigDecimal.valueOf(5.0)) > 0) {
            throw new AtsException(ReasonCode.INVALID_SCORE,
                    "Score " + score + " is outside the allowed range of 0.0 to 5.0.");
        }

        application.recordScore(round, score);

        // Rule B: Automatic rejection rule for scores below 2.0
        if (score.compareTo(BigDecimal.valueOf(2.0)) < 0) {
            CandidateStage prev = application.getCurrentStage();
            application.addStageTransition(new StageTransitionRecord(
                    prev,
                    CandidateStage.REJECTED,
                    ReasonCode.AUTO_REJECTED_LOW_SCORE,
                    "Auto-rejected due to round score " + score + " (< 2.0) in " + round
            ));
            return TransitionResult.failure(prev, CandidateStage.REJECTED,
                    ReasonCode.AUTO_REJECTED_LOW_SCORE,
                    "Candidate auto-rejected: " + round + " score " + score + " is below 2.0.");
        }

        // Check threshold for pass
        if (score.compareTo(BigDecimal.valueOf(round.getPassingScoreThreshold())) < 0) {
            ReasonCode code = (round == InterviewRound.L1) ? ReasonCode.INSUFFICIENT_L1_SCORE : ReasonCode.INSUFFICIENT_L2_SCORE;
            return TransitionResult.failure(application.getCurrentStage(), application.getCurrentStage(),
                    code,
                    "Score " + score + " is below passing threshold " + round.getPassingScoreThreshold() + " for " + round);
        }

        return TransitionResult.success(application.getCurrentStage(), application.getCurrentStage(),
                round + " score " + score + " recorded successfully.");
    }

    /**
     * Executes stage transition with validation, score gates, and headcount reservation/release.
     */
    public synchronized TransitionResult transitionStage(Application application,
                                                         Requisition requisition,
                                                         CandidateStage targetStage,
                                                         String remarks) {
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application cannot be null.");
        }
        if (targetStage == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Target stage cannot be null.");
        }

        CandidateStage currentStage = application.getCurrentStage();

        // 1. Same stage check
        if (currentStage == targetStage) {
            return TransitionResult.failure(currentStage, targetStage,
                    ReasonCode.SAME_STAGE_TRANSITION,
                    "Application " + application.getApplicationId() + " is already in stage " + currentStage);
        }

        // 2. Terminal state check
        if (currentStage.isTerminal()) {
            return TransitionResult.failure(currentStage, targetStage,
                    ReasonCode.TERMINAL_STAGE_LOCKED,
                    "Application " + application.getApplicationId() + " is in terminal stage " + currentStage + " and cannot be transitioned.");
        }

        // 3. Allowed transitions check
        Set<CandidateStage> allowed = getAllowedNextStages(currentStage);
        if (!allowed.contains(targetStage)) {
            return TransitionResult.failure(currentStage, targetStage,
                    ReasonCode.ILLEGAL_STAGE_TRANSITION,
                    "Illegal transition for application " + application.getApplicationId() + ": "
                            + currentStage + " -> " + targetStage + ". Allowed next stages: " + allowed);
        }

        // 4. Score Gates
        if (currentStage == CandidateStage.L1 && targetStage == CandidateStage.L2) {
            BigDecimal l1Score = application.getScore(InterviewRound.L1);
            if (l1Score != null && l1Score.compareTo(BigDecimal.valueOf(3.0)) < 0) {
                return TransitionResult.failure(currentStage, targetStage,
                        ReasonCode.INSUFFICIENT_L1_SCORE,
                        "Cannot advance from L1 to L2: L1 score (" + l1Score + ") is below required threshold 3.0");
            } else if (l1Score == null && enforceMandatoryScores) {
                return TransitionResult.failure(currentStage, targetStage,
                        ReasonCode.INSUFFICIENT_L1_SCORE,
                        "Cannot advance from L1 to L2: L1 score is not recorded.");
            }
        }

        if (currentStage == CandidateStage.L2 && targetStage == CandidateStage.HR) {
            BigDecimal l2Score = application.getScore(InterviewRound.L2);
            if (l2Score != null && l2Score.compareTo(BigDecimal.valueOf(3.5)) < 0) {
                return TransitionResult.failure(currentStage, targetStage,
                        ReasonCode.INSUFFICIENT_L2_SCORE,
                        "Cannot advance from L2 to HR: L2 score (" + l2Score + ") is below required threshold 3.5");
            } else if (l2Score == null && enforceMandatoryScores) {
                return TransitionResult.failure(currentStage, targetStage,
                        ReasonCode.INSUFFICIENT_L2_SCORE,
                        "Cannot advance from L2 to HR: L2 score is not recorded.");
            }
        }

        // 5. Headcount Management:
        // Transition into OFFER_DRAFT reserves 1 headcount
        if (targetStage == CandidateStage.OFFER_DRAFT) {
            if (requisition != null) {
                boolean reserved = requisition.reserveHeadcount();
                if (!reserved) {
                    return TransitionResult.failure(currentStage, targetStage,
                            ReasonCode.HEADCOUNT_EXHAUSTED,
                            "Cannot draft offer for application " + application.getApplicationId()
                                    + ": Requisition " + requisition.getRequisitionId() + " headcount exhausted.");
                }
            }
        }

        // Release headcount if moving from offer-holding stage to DECLINED, WITHDRAWN, REJECTED, or ON_HOLD
        if (currentStage.isOfferHolding() && (targetStage == CandidateStage.DECLINED ||
                targetStage == CandidateStage.WITHDRAWN ||
                targetStage == CandidateStage.REJECTED ||
                targetStage == CandidateStage.ON_HOLD)) {
            if (requisition != null) {
                requisition.releaseHeadcount();
            }
        }

        // If target is JOINED, update requisition joined count
        if (targetStage == CandidateStage.JOINED) {
            if (requisition != null) {
                requisition.markCandidateJoined();
            }
        }

        // Record transition
        String msg = (remarks == null || remarks.trim().isEmpty())
                ? "Transitioned from " + currentStage + " to " + targetStage
                : remarks.trim();
        application.addStageTransition(new StageTransitionRecord(currentStage, targetStage, ReasonCode.SUCCESS, msg));

        return TransitionResult.success(currentStage, targetStage,
                "Stage updated: Application=" + application.getApplicationId() + ", Transition=" + currentStage + " -> " + targetStage + " [SUCCESS]");
    }
}

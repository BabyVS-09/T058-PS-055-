package com.ats.service;

import com.ats.model.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Offer calculation engine implementing Week 3 Module C and Module D requirements:
 *
 * Module C:
 * - BigDecimal for all monetary calculations (scale 2, RoundingMode.HALF_UP).
 * - Start with expected CTC.
 * - Maximum permitted CTC is the lower of current CTC * 1.40 and requisition band maximum.
 * - Apply requisition band minimum as the floor.
 * - OUT_OF_BAND when expected CTC exceeds band maximum by more than 10%.
 *   (Exactly 10% above maximum is NOT OUT_OF_BAND; 10.01% above maximum is OUT_OF_BAND).
 * - OUT_OF_BAND offers cannot proceed without VP approval.
 *
 * Module D:
 * - ₹50,000 bonus for notice period <= 30 days and joining within 45 days of offer.
 * - ₹1,00,000 bonus when notice period > 60 days and candidate buys out notice.
 * - Buyout reimbursement capped at current CTC / 12.
 * - INTERNAL candidates get zero joining bonus.
 * - REFERRAL payment ₹25,000 after 90 days JOINED.
 * - AGENCY fee 8.33% of offered CTC after 90 days JOINED.
 * - CFO approval required if total cost exceeds band maximum * 1.15.
 * - Total cost = offeredCTC + applicableFee + joiningBonus (+ buyout reimbursement)
 */
public class OfferCalculator {

    public static final BigDecimal CTC_HIKE_CAP_MULTIPLIER = new BigDecimal("1.40");
    public static final BigDecimal OUT_OF_BAND_THRESHOLD_MULTIPLIER = new BigDecimal("1.10");
    public static final BigDecimal CFO_APPROVAL_THRESHOLD_MULTIPLIER = new BigDecimal("1.15");
    public static final BigDecimal EARLY_JOINER_BONUS = new BigDecimal("50000.00");
    public static final BigDecimal BUYOUT_BONUS = new BigDecimal("100000.00");
    public static final BigDecimal REFERRAL_FEE = new BigDecimal("25000.00");
    public static final BigDecimal AGENCY_FEE_RATE = new BigDecimal("0.0833");

    /**
     * Calculates candidate offer details based on profile, requisition band, and buyout details.
     *
     * @param candidate candidate profile
     * @param requisition target requisition
     * @param offerDate date offer is issued
     * @param targetJoiningDate planned joining date
     * @param buyoutNotice true if candidate is buying out notice
     * @param requestedBuyoutAmount candidate claimed buyout amount, or null
     * @return calculated OfferCalculationResult
     */
    public OfferCalculationResult calculateOffer(Candidate candidate,
                                                 Requisition requisition,
                                                 LocalDate offerDate,
                                                 LocalDate targetJoiningDate,
                                                 boolean buyoutNotice,
                                                 BigDecimal requestedBuyoutAmount) {
        if (candidate == null) {
            throw new AtsException(ReasonCode.CANDIDATE_NOT_FOUND, "Candidate cannot be null.");
        }
        if (requisition == null) {
            throw new AtsException(ReasonCode.REQUISITION_NOT_FOUND, "Requisition cannot be null.");
        }
        if (offerDate == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Offer date cannot be null.");
        }
        if (targetJoiningDate == null) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Target joining date cannot be null.");
        }

        BigDecimal currentCtc = candidate.getCurrentCtc().setScale(2, RoundingMode.HALF_UP);
        BigDecimal expectedCtc = candidate.getExpectedCtc().setScale(2, RoundingMode.HALF_UP);
        BigDecimal bandMin = requisition.getMinCtc().setScale(2, RoundingMode.HALF_UP);
        BigDecimal bandMax = requisition.getMaxCtc().setScale(2, RoundingMode.HALF_UP);

        // 1. OUT_OF_BAND check (BR-16):
        // Expected CTC exceeds band maximum by more than 10%.
        // Exactly 10% above band maximum is NOT out of band; 10.01% is out of band.
        BigDecimal tenPercentAboveMax = bandMax.multiply(OUT_OF_BAND_THRESHOLD_MULTIPLIER).setScale(2, RoundingMode.HALF_UP);
        boolean isOutOfBand = expectedCtc.compareTo(tenPercentAboveMax) > 0;

        // 2. Maximum permitted CTC: lower of current CTC * 1.40 and band maximum
        BigDecimal hikeCapped = currentCtc.multiply(CTC_HIKE_CAP_MULTIPLIER).setScale(2, RoundingMode.HALF_UP);
        BigDecimal maxPermitted = hikeCapped.min(bandMax);

        // 3. Offered CTC starts with expected CTC, capped at maxPermitted, with bandMin as floor
        BigDecimal offered = expectedCtc.min(maxPermitted);
        // Apply floor
        if (offered.compareTo(bandMin) < 0) {
            offered = bandMin;
        }
        offered = offered.setScale(2, RoundingMode.HALF_UP);

        // 4. Joining Bonuses & Buyout Reimbursement (Module D):
        BigDecimal joiningBonus = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        BigDecimal buyoutReimbursement = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);

        if (candidate.getSource() == CandidateSource.INTERNAL) {
            // Rule D: INTERNAL candidates get zero joining bonus
            joiningBonus = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
            buyoutReimbursement = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        } else {
            long daysToJoin = ChronoUnit.DAYS.between(offerDate, targetJoiningDate);

            // ₹50,000 bonus for notice period <= 30 days and joining within 45 days of offer
            if (candidate.getNoticePeriodDays() <= 30 && daysToJoin <= 45 && daysToJoin >= 0) {
                joiningBonus = joiningBonus.add(EARLY_JOINER_BONUS);
            }

            // ₹1,00,000 bonus when notice period > 60 days and candidate buys out notice
            if (candidate.getNoticePeriodDays() > 60 && buyoutNotice) {
                joiningBonus = joiningBonus.add(BUYOUT_BONUS);

                // Buyout reimbursement capped at current CTC / 12
                BigDecimal buyoutCap = currentCtc.divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_UP);
                if (requestedBuyoutAmount != null && requestedBuyoutAmount.compareTo(BigDecimal.ZERO) > 0) {
                    buyoutReimbursement = requestedBuyoutAmount.min(buyoutCap).setScale(2, RoundingMode.HALF_UP);
                } else {
                    buyoutReimbursement = buyoutCap;
                }
            }
        }

        // 5. Recruitment Fee (Module D):
        // REFERRAL payment ₹25,000 after 90 days JOINED
        // AGENCY fee 8.33% of offered CTC after 90 days JOINED
        BigDecimal recruitmentFee = BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        if (candidate.getSource() == CandidateSource.REFERRAL) {
            recruitmentFee = REFERRAL_FEE;
        } else if (candidate.getSource() == CandidateSource.AGENCY) {
            recruitmentFee = offered.multiply(AGENCY_FEE_RATE).setScale(2, RoundingMode.HALF_UP);
        }

        // 6. Total Cost = offeredCTC + applicableFee + joiningBonus + buyoutReimbursement
        BigDecimal totalCost = offered.add(recruitmentFee).add(joiningBonus).add(buyoutReimbursement)
                .setScale(2, RoundingMode.HALF_UP);

        // 7. Approval Thresholds:
        // OUT_OF_BAND requires VP approval
        boolean requiresVp = isOutOfBand;

        // CFO approval required if total cost exceeds band maximum * 1.15
        BigDecimal cfoThreshold = bandMax.multiply(CFO_APPROVAL_THRESHOLD_MULTIPLIER).setScale(2, RoundingMode.HALF_UP);
        boolean requiresCfo = totalCost.compareTo(cfoThreshold) > 0;

        StringBuilder breakdown = new StringBuilder();
        breakdown.append("Offered CTC=").append(offered)
                .append(", Expected CTC=").append(expectedCtc)
                .append(", Band=[").append(bandMin).append(" - ").append(bandMax).append("]")
                .append(", JoiningBonus=").append(joiningBonus)
                .append(", Buyout=").append(buyoutReimbursement)
                .append(", RecruitmentFee=").append(recruitmentFee)
                .append(", TotalCost=").append(totalCost)
                .append(", OutOfBand=").append(isOutOfBand)
                .append(", RequiresVP=").append(requiresVp)
                .append(", RequiresCFO=").append(requiresCfo);

        return new OfferCalculationResult(
                expectedCtc,
                offered,
                joiningBonus,
                buyoutReimbursement,
                recruitmentFee,
                totalCost,
                isOutOfBand,
                requiresVp,
                requiresCfo,
                breakdown.toString()
        );
    }
}

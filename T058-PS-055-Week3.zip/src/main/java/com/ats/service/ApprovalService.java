package com.ats.service;

import com.ats.model.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Approval matrix routing and SLA tracking service implementing Week 3 Module E:
 * - Approval order:
 *     - At or below band maximum: Hiring Manager
 *     - Above band maximum and up to 1.10 * band maximum: Hiring Manager -> HR Head
 *     - Above 1.10 * band maximum or OUT_OF_BAND: Hiring Manager -> HR Head -> VP
 *     - Add CFO approval if total cost exceeds band maximum * 1.15
 * - Sequential approvals
 * - Rejection terminates the approval chain
 * - 2 working days SLA per approver (excluding weekends and supplied holidays)
 * - On SLA breach mark TIMED_OUT and escalate to next approver
 * - Never automatically skip VP or CFO
 * - Maintain approval history
 */
public class ApprovalService {

    public static final int SLA_WORKING_DAYS = 2;
    public static final BigDecimal TEN_PERCENT_ABOVE = new BigDecimal("1.10");
    public static final BigDecimal FIFTEEN_PERCENT_ABOVE = new BigDecimal("1.15");

    private final Set<LocalDate> holidays;

    public ApprovalService() {
        this(new HashSet<>());
    }

    public ApprovalService(Set<LocalDate> holidays) {
        this.holidays = new HashSet<>(holidays != null ? holidays : Collections.emptySet());
    }

    public synchronized void addHoliday(LocalDate holiday) {
        if (holiday != null) {
            this.holidays.add(holiday);
        }
    }

    public boolean isWorkingDay(LocalDate date) {
        DayOfWeek dow = date.getDayOfWeek();
        if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
            return false;
        }
        return !holidays.contains(date);
    }

    /**
     * Calculates the SLA deadline date after adding 2 working days.
     * E.g., if assigned on Friday, Day 1 = Monday, Day 2 = Tuesday (excluding holidays).
     */
    public LocalDate calculateSlaDeadline(LocalDate assignedDate, int workingDays) {
        LocalDate current = assignedDate;
        int added = 0;
        while (added < workingDays) {
            current = current.plusDays(1);
            if (isWorkingDay(current)) {
                added++;
            }
        }
        return current;
    }

    /**
     * Builds and initializes an ApprovalMatrix for the given offer and requisition.
     */
    public ApprovalMatrix createApprovalMatrix(String approvalId, Offer offer, Requisition requisition, LocalDate requestDate) {
        if (offer == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "Offer cannot be null.");
        }
        if (requisition == null) {
            throw new AtsException(ReasonCode.REQUISITION_NOT_FOUND, "Requisition cannot be null.");
        }

        BigDecimal offeredCtc = offer.getOfferedCtc();
        BigDecimal expectedCtc = offer.getExpectedCtc();
        BigDecimal bandMax = requisition.getMaxCtc();
        BigDecimal totalCost = offer.getTotalCost();

        BigDecimal tenPercentMax = bandMax.multiply(TEN_PERCENT_ABOVE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal cfoThreshold = bandMax.multiply(FIFTEEN_PERCENT_ABOVE).setScale(2, RoundingMode.HALF_UP);

        boolean isOutOfBand = offer.isOutOfBand() || expectedCtc.compareTo(tenPercentMax) > 0;
        boolean requiresCfo = offer.isRequiresCfoApproval() || totalCost.compareTo(cfoThreshold) > 0;

        List<ApprovalStep> steps = new ArrayList<>();
        int stepNum = 1;

        // Step 1: Always Hiring Manager
        LocalDate hmDeadline = calculateSlaDeadline(requestDate, SLA_WORKING_DAYS);
        steps.add(new ApprovalStep(stepNum++, ApprovalRole.HIRING_MANAGER, requisition.getHiringManager(), requestDate, hmDeadline));

        // Step 2: HR Head if offered > bandMax OR out-of-band
        if (offeredCtc.compareTo(bandMax) > 0 || isOutOfBand) {
            LocalDate hrDeadline = calculateSlaDeadline(requestDate, SLA_WORKING_DAYS);
            steps.add(new ApprovalStep(stepNum++, ApprovalRole.HR_HEAD, "HR Head", requestDate, hrDeadline));
        }

        // Step 3: VP if offered > 1.10 * bandMax OR out-of-band
        if (offeredCtc.compareTo(tenPercentMax) > 0 || isOutOfBand) {
            LocalDate vpDeadline = calculateSlaDeadline(requestDate, SLA_WORKING_DAYS);
            steps.add(new ApprovalStep(stepNum++, ApprovalRole.VP, "VP Engineering", requestDate, vpDeadline));
        }

        // Step 4: CFO if total cost > 1.15 * bandMax
        if (requiresCfo) {
            LocalDate cfoDeadline = calculateSlaDeadline(requestDate, SLA_WORKING_DAYS);
            steps.add(new ApprovalStep(stepNum++, ApprovalRole.CFO, "Chief Financial Officer", requestDate, cfoDeadline));
        }

        ApprovalMatrix matrix = new ApprovalMatrix(approvalId, offer.getOfferId(), offer.getApplicationId(), steps);
        offer.setApprovalMatrix(matrix);
        offer.setStatus(OfferStatus.PENDING_APPROVAL);

        return matrix;
    }

    /**
     * Records an approval or rejection for the active step in the matrix.
     */
    public synchronized void recordApproval(ApprovalMatrix matrix, ApprovalRole role, boolean approve,
                                           String remarks, LocalDateTime actionTimestamp) {
        if (matrix == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "Approval matrix cannot be null.");
        }
        matrix.recordDecision(role, approve, remarks, actionTimestamp);
    }

    /**
     * Checks for SLA timeout at given evaluation date and escalates.
     */
    public synchronized boolean evaluateTimeouts(ApprovalMatrix matrix, LocalDate currentDate) {
        if (matrix == null) {
            return false;
        }
        return matrix.evaluateSlaTimeout(currentDate);
    }
}

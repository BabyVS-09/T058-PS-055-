package com.ats.service;

import com.ats.model.*;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Central ATS coordinator service managing requisitions, candidates, applications,
 * interview scheduling, offer generation, approval routing, waitlisting, and requisition ageing.
 */
public class RecruitmentService {

    private final Map<String, Requisition> requisitions = new LinkedHashMap<>();
    private final Map<String, Candidate> candidates = new LinkedHashMap<>();
    private final Map<String, Application> applications = new LinkedHashMap<>();
    private final Map<String, Interviewer> interviewers = new LinkedHashMap<>();
    private final Map<String, Offer> offers = new LinkedHashMap<>();
    private final Map<String, ApprovalMatrix> approvalMatrices = new LinkedHashMap<>();

    private final StageTransitionService stageTransitionService;
    private final InterviewScheduler interviewScheduler;
    private final OfferCalculator offerCalculator;
    private final ApprovalService approvalService;
    private Clock clock;

    public RecruitmentService() {
        this(new StageTransitionService(), new InterviewScheduler(), new OfferCalculator(), new ApprovalService(), Clock.systemDefaultZone());
    }

    public RecruitmentService(StageTransitionService stageTransitionService,
                              InterviewScheduler interviewScheduler,
                              OfferCalculator offerCalculator,
                              ApprovalService approvalService,
                              Clock clock) {
        this.stageTransitionService = stageTransitionService != null ? stageTransitionService : new StageTransitionService();
        this.interviewScheduler = interviewScheduler != null ? interviewScheduler : new InterviewScheduler();
        this.offerCalculator = offerCalculator != null ? offerCalculator : new OfferCalculator();
        this.approvalService = approvalService != null ? approvalService : new ApprovalService();
        this.clock = clock != null ? clock : Clock.systemDefaultZone();
    }

    public Clock getClock() {
        return clock;
    }

    public void setClock(Clock clock) {
        this.clock = clock;
    }

    public StageTransitionService getStageTransitionService() {
        return stageTransitionService;
    }

    public InterviewScheduler getInterviewScheduler() {
        return interviewScheduler;
    }

    public OfferCalculator getOfferCalculator() {
        return offerCalculator;
    }

    public ApprovalService getApprovalService() {
        return approvalService;
    }

    // --- REQUISITION OPERATIONS ---

    public synchronized Requisition registerRequisition(String requisitionId, String role, GradeBand gradeBand,
                                                       int headcount, String location,
                                                       BigDecimal minCtc, BigDecimal maxCtc,
                                                       String hiringManager, LocalDate openedDate) {
        if (requisitionId == null || requisitionId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Requisition ID cannot be null or empty.");
        }
        String key = requisitionId.trim();
        if (requisitions.containsKey(key)) {
            throw new AtsException(ReasonCode.DUPLICATE_REQUISITION_ID,
                    "Requisition ID '" + key + "' is already registered.");
        }

        Requisition requisition = new Requisition(key, role, gradeBand, headcount, location, minCtc, maxCtc, hiringManager, openedDate);
        requisitions.put(key, requisition);
        return requisition;
    }

    public synchronized Requisition getRequisition(String requisitionId) {
        if (requisitionId == null) return null;
        return requisitions.get(requisitionId.trim());
    }

    public synchronized Collection<Requisition> getAllRequisitions() {
        return Collections.unmodifiableCollection(requisitions.values());
    }

    // --- CANDIDATE OPERATIONS ---

    public synchronized Candidate registerCandidate(String candidateId, String name, int noticePeriodDays,
                                                     BigDecimal currentCtc, BigDecimal expectedCtc,
                                                     BigDecimal experienceYears, CandidateSource source) {
        if (candidateId == null || candidateId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Candidate ID cannot be null or empty.");
        }
        String key = candidateId.trim();
        if (candidates.containsKey(key)) {
            throw new AtsException(ReasonCode.DUPLICATE_CANDIDATE_ID,
                    "Candidate ID '" + key + "' is already registered.");
        }

        Candidate candidate = new Candidate(key, name, noticePeriodDays, currentCtc, expectedCtc, experienceYears, source);
        candidates.put(key, candidate);
        return candidate;
    }

    public synchronized Candidate getCandidate(String candidateId) {
        if (candidateId == null) return null;
        return candidates.get(candidateId.trim());
    }

    public synchronized Collection<Candidate> getAllCandidates() {
        return Collections.unmodifiableCollection(candidates.values());
    }

    // --- INTERVIEWER OPERATIONS ---

    public synchronized void registerInterviewer(Interviewer interviewer) {
        if (interviewer != null) {
            interviewers.put(interviewer.getInterviewerId(), interviewer);
            interviewScheduler.registerInterviewer(interviewer);
        }
    }

    public synchronized Interviewer getInterviewer(String interviewerId) {
        return interviewers.get(interviewerId);
    }

    // --- APPLICATION OPERATIONS ---

    public synchronized Application apply(String applicationId, String candidateId, String requisitionId, LocalDate applicationDate) {
        if (applicationId == null || applicationId.trim().isEmpty()) {
            throw new AtsException(ReasonCode.MISSING_REQUIRED_FIELD, "Application ID cannot be null or empty.");
        }
        String appKey = applicationId.trim();
        if (applications.containsKey(appKey)) {
            throw new AtsException(ReasonCode.DUPLICATE_APPLICATION_ID,
                    "Application ID '" + appKey + "' is already registered.");
        }

        Candidate candidate = getCandidate(candidateId);
        if (candidate == null) {
            throw new AtsException(ReasonCode.CANDIDATE_NOT_FOUND,
                    "Candidate ID '" + candidateId + "' does not exist.");
        }

        Requisition requisition = getRequisition(requisitionId);
        if (requisition == null) {
            throw new AtsException(ReasonCode.REQUISITION_NOT_FOUND,
                    "Requisition ID '" + requisitionId + "' does not exist.");
        }

        if (requisition.getStatus() == RequisitionStatus.CLOSED) {
            throw new AtsException(ReasonCode.REQUISITION_CLOSED,
                    "Cannot apply: Requisition " + requisitionId + " is CLOSED.");
        }

        // Prevent duplicate applications by the same candidate to the same requisition
        for (Application app : applications.values()) {
            if (app.getCandidateId().equals(candidate.getCandidateId()) &&
                    app.getRequisitionId().equals(requisition.getRequisitionId())) {
                throw new AtsException(ReasonCode.DUPLICATE_CANDIDATE_APPLICATION,
                        "Candidate '" + candidateId + "' has already applied to requisition '" + requisitionId + "'.");
            }
        }

        Application application = new Application(appKey, candidate.getCandidateId(), requisition.getRequisitionId(),
                requisition.getGradeBand(), applicationDate);
        applications.put(appKey, application);
        return application;
    }

    public synchronized Application getApplication(String applicationId) {
        if (applicationId == null) return null;
        return applications.get(applicationId.trim());
    }

    public synchronized Collection<Application> getAllApplications() {
        return Collections.unmodifiableCollection(applications.values());
    }

    // --- INTERVIEW SCHEDULING ---

    public synchronized InterviewSchedulingResult scheduleInterview(String applicationId, InterviewRound round, LocalDate fromDate) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        LocalDate date = (fromDate != null) ? fromDate : LocalDate.now(clock);
        return interviewScheduler.scheduleInterview(application, round, date);
    }

    // --- SCORE RECORDING ---

    public synchronized TransitionResult recordScore(String applicationId, InterviewRound round, BigDecimal score) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        return stageTransitionService.recordScore(application, round, score);
    }

    // --- STAGE TRANSITION ---

    public synchronized TransitionResult transitionStage(String applicationId, CandidateStage targetStage) {
        return transitionStage(applicationId, targetStage, null);
    }

    public synchronized TransitionResult transitionStage(String applicationId, CandidateStage targetStage, String remarks) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        Requisition requisition = getRequisition(application.getRequisitionId());
        return stageTransitionService.transitionStage(application, requisition, targetStage, remarks);
    }

    // --- OFFER MANAGEMENT (Modules C, D, F, G) ---

    public synchronized Offer draftOffer(String offerId, String applicationId, LocalDate offerDate,
                                         LocalDate targetJoiningDate, boolean buyoutNotice,
                                         BigDecimal requestedBuyoutAmount) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        Candidate candidate = getCandidate(application.getCandidateId());
        Requisition requisition = getRequisition(application.getRequisitionId());

        if (requisition.getStatus() == RequisitionStatus.CLOSED) {
            throw new AtsException(ReasonCode.REQUISITION_CLOSED, "Cannot draft offer: Requisition is CLOSED.");
        }

        // Rule G / BR-33: Notice period above 90 days requires target joining date at least the required notice period after offer date
        if (candidate.getNoticePeriodDays() > 90) {
            long daysToJoin = ChronoUnit.DAYS.between(offerDate, targetJoiningDate);
            if (daysToJoin < candidate.getNoticePeriodDays()) {
                throw new AtsException(ReasonCode.INVALID_NOTICE_PERIOD_JOINING_DATE,
                        "Notice period > 90 days (" + candidate.getNoticePeriodDays() + " days) requires target joining date at least "
                                + candidate.getNoticePeriodDays() + " days after offer date (actual: " + daysToJoin + " days).");
            }
        }

        // Transition to OFFER_DRAFT (reserves headcount)
        TransitionResult result = stageTransitionService.transitionStage(application, requisition, CandidateStage.OFFER_DRAFT, "Offer drafted");
        if (!result.success()) {
            throw new AtsException(result.reasonCode(), result.message());
        }

        // Calculate offer
        OfferCalculationResult calc = offerCalculator.calculateOffer(
                candidate, requisition, offerDate, targetJoiningDate, buyoutNotice, requestedBuyoutAmount);

        Offer offer = new Offer(
                offerId,
                application.getApplicationId(),
                candidate.getCandidateId(),
                requisition.getRequisitionId(),
                candidate.getCurrentCtc(),
                candidate.getExpectedCtc(),
                calc.offeredCtc(),
                calc.joiningBonus(),
                calc.buyoutReimbursement(),
                calc.recruitmentFee(),
                calc.totalCost(),
                calc.outOfBand(),
                calc.requiresVpApproval(),
                calc.requiresCfoApproval(),
                offerDate,
                targetJoiningDate
        );

        application.setOffer(offer);
        offers.put(offerId, offer);
        return offer;
    }

    public synchronized Offer getOffer(String offerId) {
        return offers.get(offerId);
    }

    // --- APPROVAL WORKFLOW (Module E) ---

    public synchronized ApprovalMatrix requestApproval(String approvalId, String offerId, LocalDate requestDate) {
        Offer offer = getOffer(offerId);
        if (offer == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "Offer " + offerId + " not found.");
        }
        Requisition requisition = getRequisition(offer.getRequisitionId());
        LocalDate date = (requestDate != null) ? requestDate : LocalDate.now(clock);

        ApprovalMatrix matrix = approvalService.createApprovalMatrix(approvalId, offer, requisition, date);
        approvalMatrices.put(approvalId, matrix);
        return matrix;
    }

    public synchronized ApprovalMatrix getApprovalMatrix(String approvalId) {
        return approvalMatrices.get(approvalId);
    }

    public synchronized void recordApproval(String approvalId, ApprovalRole role, boolean approve, String remarks, LocalDateTime timestamp) {
        ApprovalMatrix matrix = getApprovalMatrix(approvalId);
        if (matrix == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "Approval matrix " + approvalId + " not found.");
        }
        LocalDateTime ts = (timestamp != null) ? timestamp : LocalDateTime.now(clock);
        approvalService.recordApproval(matrix, role, approve, remarks, ts);

        // If fully approved, advance application to OFFER_APPROVED
        if (matrix.isFullyApproved()) {
            Offer offer = getOffer(matrix.getOfferId());
            if (offer != null) {
                offer.setStatus(OfferStatus.APPROVED);
                Application app = getApplication(offer.getApplicationId());
                if (app != null && app.getCurrentStage() == CandidateStage.OFFER_DRAFT) {
                    transitionStage(app.getApplicationId(), CandidateStage.OFFER_APPROVED, "Offer fully approved by all required stakeholders");
                }
            }
        } else if (matrix.isRejected()) {
            Offer offer = getOffer(matrix.getOfferId());
            if (offer != null) {
                offer.setStatus(OfferStatus.WITHDRAWN);
                Application app = getApplication(offer.getApplicationId());
                if (app != null) {
                    transitionStage(app.getApplicationId(), CandidateStage.REJECTED, "Offer approval rejected by " + role);
                }
            }
        }
    }

    // --- OFFER ACCEPTANCE / DECLINE / EXPIRY (Module F) ---

    public synchronized TransitionResult acceptOffer(String applicationId, LocalDateTime acceptanceDateTime) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        Offer offer = application.getOffer();
        if (offer == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "No offer found for application " + applicationId);
        }

        LocalDateTime checkTime = (acceptanceDateTime != null) ? acceptanceDateTime : LocalDateTime.now(clock);

        // Rule F: Offers valid for 7 calendar days. Day 7 at 23:59 is valid, Day 8 at 00:00 is invalid.
        if (!offer.isValidAt(checkTime)) {
            offer.setStatus(OfferStatus.EXPIRED);
            // Expired offers release reserved headcount
            transitionStage(applicationId, CandidateStage.WITHDRAWN, "Offer expired at " + checkTime);
            return TransitionResult.failure(application.getCurrentStage(), CandidateStage.WITHDRAWN,
                    ReasonCode.OFFER_EXPIRED, "Offer expired on " + offer.getValidUntil() + " (attempted acceptance at " + checkTime + ")");
        }

        // If offer is approved, ensure it was moved to OFFERED before ACCEPTED, or transition directly if OFFERED
        if (application.getCurrentStage() == CandidateStage.OFFER_APPROVED) {
            transitionStage(applicationId, CandidateStage.OFFERED, "Offer extended to candidate");
        }

        TransitionResult result = transitionStage(applicationId, CandidateStage.ACCEPTED, "Offer accepted by candidate at " + checkTime);
        if (result.success()) {
            offer.setStatus(OfferStatus.ACCEPTED);
        }
        return result;
    }

    public synchronized TransitionResult declineOffer(String applicationId, String reason) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        Offer offer = application.getOffer();
        if (offer != null) {
            offer.setStatus(OfferStatus.DECLINED);
        }
        return transitionStage(applicationId, CandidateStage.DECLINED, reason != null ? reason : "Candidate declined offer");
    }

    public synchronized TransitionResult expireOffer(String applicationId, LocalDateTime currentDateTime) {
        Application application = getApplication(applicationId);
        if (application == null) {
            throw new AtsException(ReasonCode.APPLICATION_NOT_FOUND, "Application " + applicationId + " not found.");
        }
        Offer offer = application.getOffer();
        if (offer == null) {
            throw new AtsException(ReasonCode.OFFER_NOT_FOUND, "No offer found for application " + applicationId);
        }
        LocalDateTime now = (currentDateTime != null) ? currentDateTime : LocalDateTime.now(clock);
        if (!offer.isValidAt(now)) {
            offer.setStatus(OfferStatus.EXPIRED);
            return transitionStage(applicationId, CandidateStage.WITHDRAWN, "Offer expired at " + now);
        }
        return TransitionResult.failure(application.getCurrentStage(), application.getCurrentStage(),
                ReasonCode.SUCCESS, "Offer is still valid until " + offer.getValidUntil());
    }

    public synchronized boolean releaseHeadcount(String requisitionId) {
        Requisition req = getRequisition(requisitionId);
        if (req != null) {
            return req.releaseHeadcount();
        }
        return false;
    }

    // --- WAITLIST RANKING (Module F) ---

    /**
     * Ranks waitlisted candidates for a requisition:
     * "When no headcount is available, waitlist by L2 score descending, then application date ascending."
     */
    public synchronized List<Application> rankWaitlist(String requisitionId) {
        List<Application> waitlist = new ArrayList<>();
        for (Application app : applications.values()) {
            if (app.getRequisitionId().equals(requisitionId) && app.getCurrentStage() == CandidateStage.WAITLIST) {
                waitlist.add(app);
            }
        }

        waitlist.sort((a, b) -> {
            BigDecimal scoreA = a.getScore(InterviewRound.L2) != null ? a.getScore(InterviewRound.L2) : BigDecimal.ZERO;
            BigDecimal scoreB = b.getScore(InterviewRound.L2) != null ? b.getScore(InterviewRound.L2) : BigDecimal.ZERO;
            int scoreCompare = scoreB.compareTo(scoreA); // descending
            if (scoreCompare != 0) {
                return scoreCompare;
            }
            return a.getApplicationDate().compareTo(b.getApplicationDate()); // ascending
        });

        for (int i = 0; i < waitlist.size(); i++) {
            waitlist.get(i).setWaitlistRank(i + 1);
        }

        return waitlist;
    }

    // --- REQUISITION AGEING (Module G) ---

    /**
     * Checks and updates requisition ageing:
     * - Requisition becomes AT_RISK after 45 days.
     * - Automatically close after 90 days unless headcount is reserved.
     * - On closure, move non-OFFERED candidates to ON_HOLD.
     */
    public synchronized List<String> updateRequisitionAgeing(LocalDate currentDate) {
        List<String> actions = new ArrayList<>();
        LocalDate evalDate = (currentDate != null) ? currentDate : LocalDate.now(clock);

        for (Requisition req : requisitions.values()) {
            boolean closed = req.updateAgeing(evalDate);
            if (closed) {
                actions.add("Requisition " + req.getRequisitionId() + " automatically CLOSED after 90 days on " + evalDate);
                // Move non-OFFERED candidates to ON_HOLD
                for (Application app : applications.values()) {
                    if (app.getRequisitionId().equals(req.getRequisitionId())) {
                        CandidateStage stage = app.getCurrentStage();
                        if (!stage.isOfferHolding() && !stage.isTerminal() && stage != CandidateStage.ON_HOLD) {
                            stageTransitionService.transitionStage(app, req, CandidateStage.ON_HOLD,
                                    "Requisition closed due to 90-day ageing SLA; candidate moved to ON_HOLD");
                            actions.add("Moved application " + app.getApplicationId() + " to ON_HOLD due to requisition closure");
                        }
                    }
                }
            } else if (req.getStatus() == RequisitionStatus.AT_RISK) {
                actions.add("Requisition " + req.getRequisitionId() + " is AT_RISK (" + req.getDaysOpen(evalDate) + " days open)");
            }
        }
        return actions;
    }

    // --- SYSTEM SNAPSHOT / SUMMARY ---

    public synchronized String getSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("--------------------------------------------------------------------------------\n");
        sb.append("ATS PIPELINE SNAPSHOT\n");
        sb.append("Registered Requisitions : ").append(requisitions.size()).append("\n");
        for (Requisition req : requisitions.values()) {
            sb.append("  - ").append(req.getRequisitionId())
                    .append(" | ").append(req.getRole()).append(" (").append(req.getGradeBand()).append(")")
                    .append(" | Location=").append(req.getLocation())
                    .append(" | Headcount=").append(req.getHeadcount())
                    .append(" (Reserved=").append(req.getReservedHeadcount())
                    .append(", Joined=").append(req.getJoinedHeadcount())
                    .append(", Free=").append(req.getAvailableHeadcount()).append(")")
                    .append(" | Status=").append(req.getStatus()).append("\n");
        }
        sb.append("Registered Candidates   : ").append(candidates.size()).append("\n");
        sb.append("Active/Total Applications: ").append(applications.size()).append("\n");
        for (Application app : applications.values()) {
            sb.append("  - ").append(app.getApplicationId())
                    .append(" | Candidate=").append(app.getCandidateId())
                    .append(" | Requisition=").append(app.getRequisitionId())
                    .append(" | Grade=").append(app.getTargetGrade())
                    .append(" | CurrentStage=").append(app.getCurrentStage())
                    .append(" | Transitions=").append(app.getStageHistory().size());
            if (app.getWaitlistRank() != null) {
                sb.append(" | WaitlistRank=").append(app.getWaitlistRank());
            }
            sb.append("\n");
        }
        sb.append("--------------------------------------------------------------------------------");
        return sb.toString();
    }
}

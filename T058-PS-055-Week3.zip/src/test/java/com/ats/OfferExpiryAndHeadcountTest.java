package com.ats;

import com.ats.model.*;
import com.ats.service.RecruitmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

class OfferExpiryAndHeadcountTest {

    private RecruitmentService service;
    private Requisition requisition;

    @BeforeEach
    void setUp() {
        service = new RecruitmentService();
        requisition = service.registerRequisition("REQ-1", "Lead Dev", GradeBand.G4, 1, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Vikram Desai", LocalDate.of(2026, 3, 1));
    }

    @Test
    @DisplayName("BR-29 / Module F: Offer valid on Day 7 at 23:59; invalid on Day 8 at 00:00")
    void testOfferValidityCutoff() {
        LocalDate offerDate = LocalDate.of(2026, 3, 1);
        LocalDate targetJoining = LocalDate.of(2026, 3, 20);

        service.registerCandidate("CAN-1", "Aarav", 15, new BigDecimal("1200000"), new BigDecimal("1600000"), new BigDecimal("4"), CandidateSource.PORTAL);
        Application app = service.apply("APP-1", "CAN-1", "REQ-1", offerDate);
        app.setCurrentStage(CandidateStage.HR);

        Offer offer = service.draftOffer("OFF-1", "APP-1", offerDate, targetJoining, false, null);
        app.setCurrentStage(CandidateStage.OFFERED);

        // Day 7 is March 8: at 23:59:59 it is valid
        LocalDateTime day7Cutoff = offerDate.plusDays(7).atTime(23, 59, 59);
        assertTrue(offer.isValidAt(day7Cutoff), "Day 7 at 23:59 must be valid");

        // Day 8 is March 9 at 00:00:00: invalid
        LocalDateTime day8Start = offerDate.plusDays(8).atTime(0, 0, 0);
        assertFalse(offer.isValidAt(day8Start), "Day 8 at 00:00 must be invalid");

        // Attempting to accept on Day 8 results in OFFER_EXPIRED and releases headcount
        TransitionResult res = service.acceptOffer("APP-1", day8Start);
        assertFalse(res.success());
        assertEquals(ReasonCode.OFFER_EXPIRED, res.reasonCode());
        assertEquals(1, requisition.getAvailableHeadcount(), "Expired offer must release reserved headcount");
    }

    @Test
    @DisplayName("BR-30, BR-31 / Module F: Competing candidates for final vacancy")
    void testCompetingCandidatesForFinalVacancy() {
        // Requisition headcount is 1
        service.registerCandidate("CAN-A", "Candidate A", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);
        service.registerCandidate("CAN-B", "Candidate B", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);

        Application appA = service.apply("APP-A", "CAN-A", "REQ-1", LocalDate.of(2026, 3, 1));
        Application appB = service.apply("APP-B", "CAN-B", "REQ-1", LocalDate.of(2026, 3, 2));

        appA.setCurrentStage(CandidateStage.HR);
        appB.setCurrentStage(CandidateStage.HR);

        // First candidate gets draft offer and reserves the only headcount
        Offer offerA = service.draftOffer("OFF-A", "APP-A", LocalDate.of(2026, 3, 5), LocalDate.of(2026, 3, 25), false, null);
        assertNotNull(offerA);
        assertEquals(0, requisition.getAvailableHeadcount());

        // Second candidate attempts draft offer -> fails because headcount exhausted
        AtsException ex = assertThrows(AtsException.class, () ->
                service.draftOffer("OFF-B", "APP-B", LocalDate.of(2026, 3, 5), LocalDate.of(2026, 3, 25), false, null));
        assertEquals(ReasonCode.HEADCOUNT_EXHAUSTED, ex.getReasonCode());

        // Candidate B moves to WAITLIST
        service.transitionStage("APP-B", CandidateStage.WAITLIST, "Moved to waitlist due to exhausted headcount");
        assertEquals(CandidateStage.WAITLIST, appB.getCurrentStage());

        // Candidate A declines the offer -> headcount released
        service.declineOffer("APP-A", "Candidate accepted competing counteroffer");
        assertEquals(1, requisition.getAvailableHeadcount());
        assertEquals(CandidateStage.DECLINED, appA.getCurrentStage());

        // Now Candidate B can receive the draft offer from WAITLIST
        Offer offerB = service.draftOffer("OFF-B", "APP-B", LocalDate.of(2026, 3, 6), LocalDate.of(2026, 3, 26), false, null);
        assertNotNull(offerB);
        assertEquals(0, requisition.getAvailableHeadcount());
        assertEquals(CandidateStage.OFFER_DRAFT, appB.getCurrentStage());
    }
}

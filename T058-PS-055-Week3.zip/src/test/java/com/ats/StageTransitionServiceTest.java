package com.ats;

import com.ats.model.*;
import com.ats.service.StageTransitionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class StageTransitionServiceTest {

    private StageTransitionService service;
    private Application application;
    private Requisition requisition;

    @BeforeEach
    void setUp() {
        service = new StageTransitionService(true); // strict mandatory scores
        application = new Application("APP-100", "CAN-100", "REQ-100", GradeBand.G4, LocalDate.now());
        requisition = new Requisition("REQ-100", "Role", GradeBand.G4, 1, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Manager", LocalDate.now());
    }

    @Test
    @DisplayName("BR-04: Valid forward stage progression")
    void testValidStageProgression() {
        assertEquals(CandidateStage.SCREENED, application.getCurrentStage());

        assertTrue(service.transitionStage(application, requisition, CandidateStage.L1, "Pass screen").success());
        assertEquals(CandidateStage.L1, application.getCurrentStage());

        service.recordScore(application, InterviewRound.L1, new BigDecimal("3.5"));
        assertTrue(service.transitionStage(application, requisition, CandidateStage.L2, "Pass L1").success());
        assertEquals(CandidateStage.L2, application.getCurrentStage());

        service.recordScore(application, InterviewRound.L2, new BigDecimal("4.0"));
        assertTrue(service.transitionStage(application, requisition, CandidateStage.HR, "Pass L2").success());
        assertEquals(CandidateStage.HR, application.getCurrentStage());

        assertTrue(service.transitionStage(application, requisition, CandidateStage.OFFER_DRAFT, "Pass HR").success());
        assertEquals(CandidateStage.OFFER_DRAFT, application.getCurrentStage());
        assertEquals(1, requisition.getReservedHeadcount());

        assertTrue(service.transitionStage(application, requisition, CandidateStage.OFFER_APPROVED, "Offer approved").success());
        assertTrue(service.transitionStage(application, requisition, CandidateStage.OFFERED, "Offer extended").success());
        assertTrue(service.transitionStage(application, requisition, CandidateStage.ACCEPTED, "Offer accepted").success());
        assertTrue(service.transitionStage(application, requisition, CandidateStage.JOINED, "Candidate joined").success());
        assertEquals(CandidateStage.JOINED, application.getCurrentStage());
        assertEquals(1, requisition.getJoinedHeadcount());
    }

    @Test
    @DisplayName("BR-04: Terminal stage locked")
    void testTerminalStageLocked() {
        application.setCurrentStage(CandidateStage.JOINED);
        TransitionResult res = service.transitionStage(application, requisition, CandidateStage.OFFERED, "Invalid jump");
        assertFalse(res.success());
        assertEquals(ReasonCode.TERMINAL_STAGE_LOCKED, res.reasonCode());
    }

    @Test
    @DisplayName("BR-04: Illegal stage skip rejected")
    void testIllegalStageSkip() {
        assertEquals(CandidateStage.SCREENED, application.getCurrentStage());
        TransitionResult res = service.transitionStage(application, requisition, CandidateStage.OFFER_DRAFT, "Illegal skip");
        assertFalse(res.success());
        assertEquals(ReasonCode.ILLEGAL_STAGE_TRANSITION, res.reasonCode());
    }

    @Test
    @DisplayName("BR-04: Same stage transition rejected")
    void testSameStageTransition() {
        TransitionResult res = service.transitionStage(application, requisition, CandidateStage.SCREENED, "Same stage");
        assertFalse(res.success());
        assertEquals(ReasonCode.SAME_STAGE_TRANSITION, res.reasonCode());
    }

    @Test
    @DisplayName("BR-05, BR-14 / Module B: L1 score >= 3.0 passes, < 3.0 fails")
    void testL1ScoreThreshold() {
        application.setCurrentStage(CandidateStage.L1);

        // Score 2.99 fails L1 passing threshold
        TransitionResult r1 = service.recordScore(application, InterviewRound.L1, new BigDecimal("2.99"));
        assertFalse(r1.success());
        assertEquals(ReasonCode.INSUFFICIENT_L1_SCORE, r1.reasonCode());

        // Attempting to advance to L2 fails
        TransitionResult r2 = service.transitionStage(application, requisition, CandidateStage.L2, null);
        assertFalse(r2.success());
        assertEquals(ReasonCode.INSUFFICIENT_L1_SCORE, r2.reasonCode());

        // Score 3.00 passes exactly
        TransitionResult r3 = service.recordScore(application, InterviewRound.L1, new BigDecimal("3.00"));
        assertTrue(r3.success());
        assertTrue(service.transitionStage(application, requisition, CandidateStage.L2, null).success());
    }

    @Test
    @DisplayName("BR-06, BR-14 / Module B: L2 score >= 3.5 passes, < 3.5 fails")
    void testL2ScoreThreshold() {
        application.setCurrentStage(CandidateStage.L2);

        // Score 3.49 fails L2 passing threshold
        TransitionResult r1 = service.recordScore(application, InterviewRound.L2, new BigDecimal("3.49"));
        assertFalse(r1.success());
        assertEquals(ReasonCode.INSUFFICIENT_L2_SCORE, r1.reasonCode());

        TransitionResult r2 = service.transitionStage(application, requisition, CandidateStage.HR, null);
        assertFalse(r2.success());
        assertEquals(ReasonCode.INSUFFICIENT_L2_SCORE, r2.reasonCode());

        // Score 3.50 passes exactly
        TransitionResult r3 = service.recordScore(application, InterviewRound.L2, new BigDecimal("3.50"));
        assertTrue(r3.success());
        assertTrue(service.transitionStage(application, requisition, CandidateStage.HR, null).success());
    }

    @Test
    @DisplayName("BR-07, BR-14 / Module B: Score < 2.0 triggers automatic rejection")
    void testScoreBelowTwoAutoRejection() {
        application.setCurrentStage(CandidateStage.L1);

        TransitionResult res = service.recordScore(application, InterviewRound.L1, new BigDecimal("1.90"));
        assertFalse(res.success());
        assertEquals(ReasonCode.AUTO_REJECTED_LOW_SCORE, res.reasonCode());
        assertEquals(CandidateStage.REJECTED, application.getCurrentStage());
    }

    @Test
    @DisplayName("BR-14 / Module B: Scores outside 0.0-5.0 are rejected")
    void testScoreRangeValidation() {
        application.setCurrentStage(CandidateStage.L1);

        AtsException ex1 = assertThrows(AtsException.class, () ->
                service.recordScore(application, InterviewRound.L1, new BigDecimal("-0.1")));
        assertEquals(ReasonCode.INVALID_SCORE, ex1.getReasonCode());

        AtsException ex2 = assertThrows(AtsException.class, () ->
                service.recordScore(application, InterviewRound.L1, new BigDecimal("5.01")));
        assertEquals(ReasonCode.INVALID_SCORE, ex2.getReasonCode());
    }

    @Test
    @DisplayName("BR-30, BR-31 / Module F: Headcount exhaustion and release")
    void testHeadcountExhaustionAndRelease() {
        application.setCurrentStage(CandidateStage.HR);
        assertEquals(1, requisition.getAvailableHeadcount());

        // Move to OFFER_DRAFT reserves 1 headcount
        assertTrue(service.transitionStage(application, requisition, CandidateStage.OFFER_DRAFT, "Draft").success());
        assertEquals(0, requisition.getAvailableHeadcount());

        // Second candidate attempts to enter OFFER_DRAFT -> fails with HEADCOUNT_EXHAUSTED
        Application app2 = new Application("APP-200", "CAN-200", "REQ-100", GradeBand.G4, LocalDate.now());
        app2.setCurrentStage(CandidateStage.HR);
        TransitionResult r2 = service.transitionStage(app2, requisition, CandidateStage.OFFER_DRAFT, "Draft");
        assertFalse(r2.success());
        assertEquals(ReasonCode.HEADCOUNT_EXHAUSTED, r2.reasonCode());

        // First candidate declines -> releases headcount
        service.transitionStage(application, requisition, CandidateStage.OFFER_APPROVED, "Approved");
        service.transitionStage(application, requisition, CandidateStage.OFFERED, "Offered");
        service.transitionStage(application, requisition, CandidateStage.DECLINED, "Declined");
        assertEquals(1, requisition.getAvailableHeadcount());

        // Now second candidate can reserve
        assertTrue(service.transitionStage(app2, requisition, CandidateStage.OFFER_DRAFT, "Draft now").success());
        assertEquals(0, requisition.getAvailableHeadcount());
    }
}

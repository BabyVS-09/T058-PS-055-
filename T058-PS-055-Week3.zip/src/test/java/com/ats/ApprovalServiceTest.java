package com.ats;

import com.ats.model.*;
import com.ats.service.ApprovalService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ApprovalServiceTest {

    private ApprovalService approvalService;
    private Requisition requisition; // Band 10L - 20L

    @BeforeEach
    void setUp() {
        approvalService = new ApprovalService();
        requisition = new Requisition("REQ-1", "Role", GradeBand.G4, 1, "Bengaluru",
                new BigDecimal("1000000.00"), new BigDecimal("2000000.00"), "Vikram Desai", LocalDate.of(2026, 3, 1));
    }

    @Test
    @DisplayName("BR-25 / Module E: At or below bandMax requires only Hiring Manager")
    void testApprovalOrderAtOrBelowBandMax() {
        Offer offer = new Offer("OFF-1", "APP-1", "CAN-1", "REQ-1",
                new BigDecimal("1400000"), new BigDecimal("1800000"), new BigDecimal("1800000"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("1800000"),
                false, false, false, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-1", offer, requisition, LocalDate.of(2026, 3, 1));

        List<ApprovalStep> steps = matrix.getSteps();
        assertEquals(1, steps.size());
        assertEquals(ApprovalRole.HIRING_MANAGER, steps.get(0).getRole());
    }

    @Test
    @DisplayName("BR-25 / Module E: Above bandMax up to 1.10*bandMax requires Hiring Manager -> HR Head")
    void testApprovalOrderUpToTenPercent() {
        // Offered CTC = 21,00,000 (BandMax = 20,00,000; 1.10*BandMax = 22,00,000)
        Offer offer = new Offer("OFF-2", "APP-2", "CAN-2", "REQ-1",
                new BigDecimal("1600000"), new BigDecimal("2100000"), new BigDecimal("2100000"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("2100000"),
                false, false, false, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-2", offer, requisition, LocalDate.of(2026, 3, 1));

        List<ApprovalStep> steps = matrix.getSteps();
        assertEquals(2, steps.size());
        assertEquals(ApprovalRole.HIRING_MANAGER, steps.get(0).getRole());
        assertEquals(ApprovalRole.HR_HEAD, steps.get(1).getRole());
    }

    @Test
    @DisplayName("BR-25 / Module E: Above 1.10*bandMax or OUT_OF_BAND requires Hiring Manager -> HR Head -> VP")
    void testApprovalOrderAboveTenPercentOrOutOfBand() {
        Offer offer = new Offer("OFF-3", "APP-3", "CAN-3", "REQ-1",
                new BigDecimal("1800000"), new BigDecimal("2300000"), new BigDecimal("2000000"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("2000000"),
                true, true, false, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-3", offer, requisition, LocalDate.of(2026, 3, 1));

        List<ApprovalStep> steps = matrix.getSteps();
        assertEquals(3, steps.size());
        assertEquals(ApprovalRole.HIRING_MANAGER, steps.get(0).getRole());
        assertEquals(ApprovalRole.HR_HEAD, steps.get(1).getRole());
        assertEquals(ApprovalRole.VP, steps.get(2).getRole());
    }

    @Test
    @DisplayName("BR-25 / Module E: Total cost > 1.15*bandMax adds CFO approval")
    void testApprovalOrderRequiresCfo() {
        // Total cost = 24,00,000 > 1.15 * 20,00,000 (23,00,000)
        Offer offer = new Offer("OFF-4", "APP-4", "CAN-4", "REQ-1",
                new BigDecimal("1800000"), new BigDecimal("2000000"), new BigDecimal("2000000"),
                new BigDecimal("100000"), new BigDecimal("100000"), new BigDecimal("200000"), new BigDecimal("2400000"),
                false, false, true, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-4", offer, requisition, LocalDate.of(2026, 3, 1));

        List<ApprovalStep> steps = matrix.getSteps();
        assertEquals(2, steps.size()); // HM + CFO
        assertEquals(ApprovalRole.HIRING_MANAGER, steps.get(0).getRole());
        assertEquals(ApprovalRole.CFO, steps.get(1).getRole());
    }

    @Test
    @DisplayName("BR-26 / Module E: Rejection terminates the approval chain")
    void testRejectionTerminatesChain() {
        Offer offer = new Offer("OFF-5", "APP-5", "CAN-5", "REQ-1",
                new BigDecimal("1600000"), new BigDecimal("2100000"), new BigDecimal("2100000"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("2100000"),
                false, false, false, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-5", offer, requisition, LocalDate.of(2026, 3, 1));

        // Hiring manager rejects
        approvalService.recordApproval(matrix, ApprovalRole.HIRING_MANAGER, false, "Budget concern", LocalDateTime.now());

        assertTrue(matrix.isRejected());
        assertEquals(ApprovalStatus.REJECTED, matrix.getOverallStatus());

        // Subsequent approval cannot proceed
        assertThrows(AtsException.class, () ->
                approvalService.recordApproval(matrix, ApprovalRole.HR_HEAD, true, "Approved", LocalDateTime.now()));
    }

    @Test
    @DisplayName("BR-27 / Module E: Friday deadline calculation spans over weekend to Tuesday")
    void testFridayDeadlineExcludesWeekend() {
        LocalDate friday = LocalDate.of(2026, 3, 6); // Friday
        LocalDate deadline = approvalService.calculateSlaDeadline(friday, 2);

        // Friday + 1 working day = Monday (March 9)
        // Friday + 2 working days = Tuesday (March 10)
        assertEquals(LocalDate.of(2026, 3, 10), deadline);
    }

    @Test
    @DisplayName("BR-28 / Module E: SLA timeout escalates HM/HR, but NEVER auto-skips VP or CFO")
    void testSlaTimeoutAndNonSkippableVpCfo() {
        Offer offer = new Offer("OFF-6", "APP-6", "CAN-6", "REQ-1",
                new BigDecimal("1800000"), new BigDecimal("2300000"), new BigDecimal("2000000"),
                BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("2000000"),
                true, true, false, LocalDate.of(2026, 3, 2), LocalDate.of(2026, 4, 1));

        ApprovalMatrix matrix = approvalService.createApprovalMatrix("APPR-6", offer, requisition, LocalDate.of(2026, 3, 2)); // Mon March 2
        // Steps: 1: HM (deadline March 4), 2: HR_HEAD (deadline March 4), 3: VP (deadline March 4)

        // On March 5, HM SLA is breached -> HM marked TIMED_OUT and escalated to HR_HEAD
        assertTrue(approvalService.evaluateTimeouts(matrix, LocalDate.of(2026, 3, 5)));
        assertEquals(ApprovalRole.HR_HEAD, matrix.getCurrentStep().getRole());

        // On March 5, HR_HEAD also breached -> HR_HEAD marked TIMED_OUT and escalated to VP
        assertTrue(approvalService.evaluateTimeouts(matrix, LocalDate.of(2026, 3, 5)));
        assertEquals(ApprovalRole.VP, matrix.getCurrentStep().getRole());

        // On March 5, VP is current. Even though breached, VP is NEVER auto-skipped!
        boolean vpEscalated = approvalService.evaluateTimeouts(matrix, LocalDate.of(2026, 3, 5));
        assertFalse(vpEscalated, "VP must NEVER be automatically skipped on SLA timeout");
        assertEquals(ApprovalRole.VP, matrix.getCurrentStep().getRole());
        assertEquals(ApprovalStatus.PENDING, matrix.getCurrentStep().getStatus());
    }
}

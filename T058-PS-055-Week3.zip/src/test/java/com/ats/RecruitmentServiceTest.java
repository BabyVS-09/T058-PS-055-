package com.ats;

import com.ats.model.*;
import com.ats.service.RecruitmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for RecruitmentService core operations, requisitions, candidates, applications,
 * waitlisting, and requisition ageing.
 */
class RecruitmentServiceTest {

    private RecruitmentService service;

    @BeforeEach
    void setUp() {
        service = new RecruitmentService();
    }

    @Test
    @DisplayName("BR-01: Register valid requisition successfully")
    void testRegisterValidRequisition() {
        Requisition req = service.registerRequisition(
                "REQ-101", "Senior Java Engineer", GradeBand.G4, 2, "Bengaluru",
                new BigDecimal("1400000"), new BigDecimal("2200000"), "Vikram Desai", LocalDate.of(2026, 3, 1)
        );

        assertNotNull(req);
        assertEquals("REQ-101", req.getRequisitionId());
        assertEquals(2, req.getHeadcount());
        assertEquals(2, req.getAvailableHeadcount());
        assertEquals(RequisitionStatus.OPEN, req.getStatus());
    }

    @Test
    @DisplayName("BR-01: Reject duplicate requisition ID")
    void testRejectDuplicateRequisitionId() {
        service.registerRequisition("REQ-101", "Role 1", GradeBand.G4, 1, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("1500000"), "Manager", LocalDate.now());

        AtsException ex = assertThrows(AtsException.class, () ->
                service.registerRequisition("REQ-101", "Role 2", GradeBand.G4, 1, "Bengaluru",
                        new BigDecimal("1000000"), new BigDecimal("1500000"), "Manager", LocalDate.now()));

        assertEquals(ReasonCode.DUPLICATE_REQUISITION_ID, ex.getReasonCode());
    }

    @Test
    @DisplayName("BR-01: Reject requisition where minCtc > maxCtc")
    void testRejectInvalidCtcBand() {
        AtsException ex = assertThrows(AtsException.class, () ->
                service.registerRequisition("REQ-102", "Role", GradeBand.G3, 1, "Bengaluru",
                        new BigDecimal("2000000"), new BigDecimal("1500000"), "Manager", LocalDate.now()));

        assertEquals(ReasonCode.INVALID_CTC, ex.getReasonCode());
    }

    @Test
    @DisplayName("BR-01: Reject non-positive headcount")
    void testRejectNonPositiveHeadcount() {
        AtsException ex = assertThrows(AtsException.class, () ->
                service.registerRequisition("REQ-103", "Role", GradeBand.G3, 0, "Bengaluru",
                        new BigDecimal("1000000"), new BigDecimal("1500000"), "Manager", LocalDate.now()));

        assertEquals(ReasonCode.INVALID_HEADCOUNT, ex.getReasonCode());
    }

    @Test
    @DisplayName("BR-02: Register valid candidate successfully")
    void testRegisterCandidate() {
        Candidate c = service.registerCandidate(
                "CAN-201", "Aarav Kulkarni", 30, new BigDecimal("1350000"),
                new BigDecimal("1800000"), new BigDecimal("5.5"), CandidateSource.REFERRAL
        );

        assertNotNull(c);
        assertEquals("CAN-201", c.getCandidateId());
        assertEquals("Aarav Kulkarni", c.getName());
        assertEquals(30, c.getNoticePeriodDays());
    }

    @Test
    @DisplayName("BR-02: Allow fresher candidate with 0 current CTC")
    void testAllowFresherZeroCurrentCtc() {
        Candidate c = service.registerCandidate(
                "CAN-202", "Pooja Hegde", 0, BigDecimal.ZERO,
                new BigDecimal("600000"), BigDecimal.ZERO, CandidateSource.PORTAL
        );

        assertNotNull(c);
        assertEquals(new BigDecimal("0.00"), c.getCurrentCtc());
    }

    @Test
    @DisplayName("BR-02: Reject candidate with negative current CTC")
    void testRejectNegativeCurrentCtc() {
        AtsException ex = assertThrows(AtsException.class, () ->
                service.registerCandidate("CAN-203", "Test", 30, new BigDecimal("-1000"),
                        new BigDecimal("500000"), BigDecimal.ONE, CandidateSource.PORTAL));

        assertEquals(ReasonCode.INVALID_CTC, ex.getReasonCode());
    }

    @Test
    @DisplayName("BR-03: Create valid application and reject duplicates")
    void testCandidateApplication() {
        service.registerRequisition("REQ-101", "Role", GradeBand.G4, 2, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Manager", LocalDate.now());
        service.registerCandidate("CAN-201", "Aarav", 30, new BigDecimal("1000000"),
                new BigDecimal("1500000"), new BigDecimal("4.0"), CandidateSource.REFERRAL);

        Application app = service.apply("APP-301", "CAN-201", "REQ-101", LocalDate.now());
        assertNotNull(app);
        assertEquals(CandidateStage.SCREENED, app.getCurrentStage());

        // Duplicate application by same candidate to same requisition
        AtsException ex = assertThrows(AtsException.class, () ->
                service.apply("APP-302", "CAN-201", "REQ-101", LocalDate.now()));
        assertEquals(ReasonCode.DUPLICATE_CANDIDATE_APPLICATION, ex.getReasonCode());
    }

    @Test
    @DisplayName("BR-32 / Module F: Waitlist ranking by L2 score desc, then application date asc")
    void testWaitlistRanking() {
        service.registerRequisition("REQ-101", "Role", GradeBand.G4, 1, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Manager", LocalDate.now());

        service.registerCandidate("CAN-1", "Alice", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);
        service.registerCandidate("CAN-2", "Bob", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);
        service.registerCandidate("CAN-3", "Charlie", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);

        Application app1 = service.apply("APP-1", "CAN-1", "REQ-101", LocalDate.of(2026, 3, 5));
        Application app2 = service.apply("APP-2", "CAN-2", "REQ-101", LocalDate.of(2026, 3, 2));
        Application app3 = service.apply("APP-3", "CAN-3", "REQ-101", LocalDate.of(2026, 3, 4));

        app1.setCurrentStage(CandidateStage.WAITLIST);
        app1.recordScore(InterviewRound.L2, new BigDecimal("3.8"));

        app2.setCurrentStage(CandidateStage.WAITLIST);
        app2.recordScore(InterviewRound.L2, new BigDecimal("4.5"));

        app3.setCurrentStage(CandidateStage.WAITLIST);
        app3.recordScore(InterviewRound.L2, new BigDecimal("3.8"));

        List<Application> ranked = service.rankWaitlist("REQ-101");

        assertEquals(3, ranked.size());
        assertEquals("APP-2", ranked.get(0).getApplicationId(), "Highest score 4.5 should be rank 1");
        assertEquals("APP-3", ranked.get(1).getApplicationId(), "Tied score 3.8 with earlier application date (March 4 vs March 5) should be rank 2");
        assertEquals("APP-1", ranked.get(2).getApplicationId(), "Tied score 3.8 with later application date should be rank 3");
        assertEquals(1, ranked.get(0).getWaitlistRank());
        assertEquals(2, ranked.get(1).getWaitlistRank());
        assertEquals(3, ranked.get(2).getWaitlistRank());
    }

    @Test
    @DisplayName("BR-34, BR-35 / Module G: Requisition ageing 44, 45, 89, 90 days and auto-closure")
    void testRequisitionAgeing() {
        LocalDate opened = LocalDate.of(2026, 1, 1);
        Requisition req = service.registerRequisition("REQ-101", "Role", GradeBand.G4, 2, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Manager", opened);

        service.registerCandidate("CAN-1", "Alice", 30, new BigDecimal("1000000"), new BigDecimal("1400000"), new BigDecimal("3"), CandidateSource.PORTAL);
        Application app = service.apply("APP-1", "CAN-1", "REQ-101", opened);

        // Day 44: Still OPEN
        service.updateRequisitionAgeing(opened.plusDays(44));
        assertEquals(RequisitionStatus.OPEN, req.getStatus());

        // Day 45: AT_RISK
        service.updateRequisitionAgeing(opened.plusDays(45));
        assertEquals(RequisitionStatus.AT_RISK, req.getStatus());

        // Day 89: Still AT_RISK
        service.updateRequisitionAgeing(opened.plusDays(89));
        assertEquals(RequisitionStatus.AT_RISK, req.getStatus());

        // Day 90 without reserved headcount: Automatically CLOSED & non-offered candidates moved to ON_HOLD
        service.updateRequisitionAgeing(opened.plusDays(90));
        assertEquals(RequisitionStatus.CLOSED, req.getStatus());
        assertEquals(CandidateStage.ON_HOLD, app.getCurrentStage());
    }

    @Test
    @DisplayName("BR-35 / Module G: Reserved headcount prevents 90-day auto-closure")
    void testReservedHeadcountPreventsAutoClosure() {
        LocalDate opened = LocalDate.of(2026, 1, 1);
        Requisition req = service.registerRequisition("REQ-101", "Role", GradeBand.G4, 2, "Bengaluru",
                new BigDecimal("1000000"), new BigDecimal("2000000"), "Manager", opened);

        req.reserveHeadcount();
        assertEquals(1, req.getReservedHeadcount());

        service.updateRequisitionAgeing(opened.plusDays(90));
        assertNotEquals(RequisitionStatus.CLOSED, req.getStatus(), "Requisition with reserved headcount should not close");
        assertEquals(RequisitionStatus.AT_RISK, req.getStatus());
    }
}

package com.ats;

import com.ats.model.*;
import com.ats.service.OfferCalculator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class OfferCalculatorTest {

    private OfferCalculator calculator;
    private Requisition requisition; // Band 14,00,000 to 20,00,000

    @BeforeEach
    void setUp() {
        calculator = new OfferCalculator();
        requisition = new Requisition(
                "REQ-1", "Lead Engineer", GradeBand.G4, 2, "Bengaluru",
                new BigDecimal("1400000.00"), new BigDecimal("2000000.00"), "Vikram Desai", LocalDate.of(2026, 3, 1)
        );
    }

    @Test
    @DisplayName("BR-15 / Module C: Normal CTC calculation capped by 40% hike")
    void testNormalCtcCalculationHikeCap() {
        // Current CTC = 10,00,000 -> 40% hike = 14,00,000.
        // Expected CTC = 16,00,000.
        // Offered CTC should be capped at 14,00,000.
        Candidate candidate = new Candidate("CAN-1", "Aarav", 30,
                new BigDecimal("1000000.00"), new BigDecimal("1600000.00"), new BigDecimal("5.0"), CandidateSource.PORTAL);

        OfferCalculationResult res = calculator.calculateOffer(
                candidate, requisition, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1), false, null);

        assertEquals(new BigDecimal("1400000.00"), res.offeredCtc());
        assertFalse(res.outOfBand());
    }

    @Test
    @DisplayName("BR-15 / Module C: Requisition band minimum applied as floor")
    void testBandMinimumAsFloor() {
        // Current CTC = 6,00,000. 40% hike = 8,40,000.
        // Requisition band min = 14,00,000.
        // Band floor must raise offered CTC to 14,00,000.
        Candidate candidate = new Candidate("CAN-2", "Diya", 30,
                new BigDecimal("600000.00"), new BigDecimal("800000.00"), new BigDecimal("3.0"), CandidateSource.PORTAL);

        OfferCalculationResult res = calculator.calculateOffer(
                candidate, requisition, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1), false, null);

        assertEquals(new BigDecimal("1400000.00"), res.offeredCtc());
    }

    @Test
    @DisplayName("BR-16 / Module C: Exactly 10% above bandMax is NOT OUT_OF_BAND; 10.01% IS OUT_OF_BAND")
    void testOutOfBandBoundaries() {
        // Band max = 20,00,000.
        // Exactly 10% above = 22,00,000.00.
        Candidate candidateExact10 = new Candidate("CAN-EXACT", "John", 30,
                new BigDecimal("1800000.00"), new BigDecimal("2200000.00"), new BigDecimal("6.0"), CandidateSource.PORTAL);

        OfferCalculationResult resExact = calculator.calculateOffer(
                candidateExact10, requisition, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1), false, null);

        assertFalse(resExact.outOfBand(), "Exactly 10% above bandMax is NOT OUT_OF_BAND");
        assertFalse(resExact.requiresVpApproval());

        // 10.01% above = 22,00,200.00 (or 22,00,000.01)
        Candidate candidateOver10 = new Candidate("CAN-OVER", "Jane", 30,
                new BigDecimal("1800000.00"), new BigDecimal("2200200.00"), new BigDecimal("6.0"), CandidateSource.PORTAL);

        OfferCalculationResult resOver = calculator.calculateOffer(
                candidateOver10, requisition, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 4, 1), false, null);

        assertTrue(resOver.outOfBand(), "10.01% above bandMax IS OUT_OF_BAND");
        assertTrue(resOver.requiresVpApproval(), "OUT_OF_BAND requires VP approval");
    }

    @Test
    @DisplayName("BR-17 / Module D: Notice period <= 30 days and joining within 45 days gets ₹50,000 bonus")
    void testEarlyJoinerBonusBoundaries() {
        LocalDate offerDate = LocalDate.of(2026, 3, 1);

        // Notice period 0 days, joining in 10 days -> ₹50k bonus
        Candidate can0 = new Candidate("CAN-0", "C0", 0, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("4"), CandidateSource.PORTAL);
        assertEquals(new BigDecimal("50000.00"), calculator.calculateOffer(can0, requisition, offerDate, offerDate.plusDays(10), false, null).joiningBonus());

        // Notice period 30 days, joining exactly on day 45 -> ₹50k bonus
        Candidate can30 = new Candidate("CAN-30", "C30", 30, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("4"), CandidateSource.PORTAL);
        assertEquals(new BigDecimal("50000.00"), calculator.calculateOffer(can30, requisition, offerDate, offerDate.plusDays(45), false, null).joiningBonus());

        // Notice period 31 days, joining within 45 days -> ₹0 bonus
        Candidate can31 = new Candidate("CAN-31", "C31", 31, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("4"), CandidateSource.PORTAL);
        assertEquals(new BigDecimal("0.00"), calculator.calculateOffer(can31, requisition, offerDate, offerDate.plusDays(20), false, null).joiningBonus());

        // Notice period 30 days, joining on day 46 -> ₹0 bonus
        assertEquals(new BigDecimal("0.00"), calculator.calculateOffer(can30, requisition, offerDate, offerDate.plusDays(46), false, null).joiningBonus());
    }

    @Test
    @DisplayName("BR-18, BR-19 / Module D: Notice period > 60 days with buyout gets ₹1,00,000 bonus and buyout capped at CTC/12")
    void testBuyoutBonusAndCap() {
        LocalDate offerDate = LocalDate.of(2026, 3, 1);

        // Notice period 60 days with buyout -> ₹0 buyout bonus (rule requires > 60 days)
        Candidate can60 = new Candidate("CAN-60", "C60", 60, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("5"), CandidateSource.PORTAL);
        OfferCalculationResult res60 = calculator.calculateOffer(can60, requisition, offerDate, offerDate.plusDays(60), true, new BigDecimal("100000"));
        assertEquals(new BigDecimal("0.00"), res60.joiningBonus());

        // Notice period 61 days with buyout -> ₹1,00,000 bonus
        // Current CTC = 12,00,000 -> Buyout cap = 12,00,000 / 12 = 1,00,000.00
        Candidate can61 = new Candidate("CAN-61", "C61", 61, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("5"), CandidateSource.PORTAL);
        OfferCalculationResult res61 = calculator.calculateOffer(can61, requisition, offerDate, offerDate.plusDays(61), true, new BigDecimal("150000"));
        assertEquals(new BigDecimal("100000.00"), res61.joiningBonus());
        assertEquals(new BigDecimal("100000.00"), res61.buyoutReimbursement(), "Buyout reimbursement capped at CTC / 12");

        // Notice period 91 days with buyout -> ₹1,00,000 bonus
        Candidate can91 = new Candidate("CAN-91", "C91", 91, new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("5"), CandidateSource.PORTAL);
        OfferCalculationResult res91 = calculator.calculateOffer(can91, requisition, offerDate, offerDate.plusDays(95), true, new BigDecimal("80000"));
        assertEquals(new BigDecimal("100000.00"), res91.joiningBonus());
        assertEquals(new BigDecimal("80000.00"), res91.buyoutReimbursement());
    }

    @Test
    @DisplayName("BR-20 / Module D: INTERNAL candidates get zero joining bonus")
    void testInternalCandidatesGetZeroBonus() {
        Candidate internal = new Candidate("CAN-INT", "Internal Emp", 15,
                new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("4"), CandidateSource.INTERNAL);

        OfferCalculationResult res = calculator.calculateOffer(
                internal, requisition, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 3, 15), true, new BigDecimal("50000"));

        assertEquals(new BigDecimal("0.00"), res.joiningBonus());
        assertEquals(new BigDecimal("0.00"), res.buyoutReimbursement());
    }

    @Test
    @DisplayName("BR-21, BR-22, BR-24 / Module D: Recruitment fee and CFO approval threshold")
    void testRecruitmentFeeAndCfoThreshold() {
        LocalDate offerDate = LocalDate.of(2026, 3, 1);

        // REFERRAL fee = ₹25,000
        Candidate referral = new Candidate("CAN-REF", "Ref", 45,
                new BigDecimal("1200000"), new BigDecimal("1500000"), new BigDecimal("4"), CandidateSource.REFERRAL);
        OfferCalculationResult resRef = calculator.calculateOffer(
                referral, requisition, offerDate, offerDate.plusDays(45), false, null);
        assertEquals(new BigDecimal("25000.00"), resRef.recruitmentFee());

        // AGENCY fee = 8.33% of offered CTC
        Candidate agency = new Candidate("CAN-AGY", "Agy", 45,
                new BigDecimal("1400000"), new BigDecimal("1800000"), new BigDecimal("5"), CandidateSource.AGENCY);
        OfferCalculationResult resAgy = calculator.calculateOffer(
                agency, requisition, offerDate, offerDate.plusDays(45), false, null);
        // Offered CTC = min(1400000*1.40=1960000, 2000000) = 1800000 expected -> 1800000.
        // 8.33% of 1800000 = 149940.00
        assertEquals(new BigDecimal("149940.00"), resAgy.recruitmentFee());

        // Total cost test for CFO threshold (bandMax * 1.15 = 20,00,000 * 1.15 = 23,00,000)
        // If offered = 20,00,000, agency fee = 1,66,600, buyout bonus = 1,00,000, buyout = 1,00,000 -> total = 23,66,600 > 23,00,000 -> requires CFO!
        Candidate highCostCandidate = new Candidate("CAN-HIGH", "High", 70,
                new BigDecimal("1800000"), new BigDecimal("2000000"), new BigDecimal("8"), CandidateSource.AGENCY);
        OfferCalculationResult resHigh = calculator.calculateOffer(
                highCostCandidate, requisition, offerDate, offerDate.plusDays(70), true, new BigDecimal("150000"));
        assertTrue(resHigh.requiresCfoApproval(), "Total cost > 1.15 * bandMax requires CFO approval");
    }
}

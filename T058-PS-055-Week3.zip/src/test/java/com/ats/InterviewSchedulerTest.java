package com.ats;

import com.ats.model.*;
import com.ats.service.InterviewScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class InterviewSchedulerTest {

    private InterviewScheduler scheduler;
    private Interviewer interviewerG5;
    private Interviewer interviewerG3;
    private Application applicationG4;

    @BeforeEach
    void setUp() {
        interviewerG5 = new Interviewer("INT-1", "Senior Architect", GradeBand.G5);
        interviewerG3 = new Interviewer("INT-2", "Software Engineer", GradeBand.G3);

        scheduler = new InterviewScheduler();
        scheduler.registerInterviewer(interviewerG5);
        scheduler.registerInterviewer(interviewerG3);

        applicationG4 = new Application("APP-1", "CAN-1", "REQ-1", GradeBand.G4, LocalDate.of(2026, 3, 2));
    }

    @Test
    @DisplayName("BR-08 / Module A: Correct interview durations for L1 (60m), L2 (45m), and HR (30m)")
    void testInterviewDurations() {
        assertEquals(60, InterviewRound.L1.getDefaultDurationMinutes());
        assertEquals(45, InterviewRound.L2.getDefaultDurationMinutes());
        assertEquals(30, InterviewRound.HR.getDefaultDurationMinutes());

        LocalDate start = LocalDate.of(2026, 3, 2); // Monday
        InterviewSchedulingResult resL1 = scheduler.scheduleInterview(applicationG4, InterviewRound.L1, start);
        assertTrue(resL1.success());
        assertEquals(60, java.time.Duration.between(
                resL1.bookedSlot().getStartDateTime(), resL1.bookedSlot().getEndDateTime()).toMinutes());
    }

    @Test
    @DisplayName("BR-09 / Module A: Maximum 3 interviews per interviewer per day")
    void testMaxThreeInterviewsPerDay() {
        LocalDate monday = LocalDate.of(2026, 3, 2);

        // Book 3 slots on Monday for interviewerG5
        interviewerG5.bookSlot(new InterviewSlot("S1", "APP-1", "CAN-1", "INT-1", GradeBand.G5,
                InterviewRound.L1, LocalDateTime.of(monday, LocalTime.of(9, 0)), LocalDateTime.of(monday, LocalTime.of(10, 0))));
        interviewerG5.bookSlot(new InterviewSlot("S2", "APP-2", "CAN-2", "INT-1", GradeBand.G5,
                InterviewRound.L1, LocalDateTime.of(monday, LocalTime.of(11, 0)), LocalDateTime.of(monday, LocalTime.of(12, 0))));
        interviewerG5.bookSlot(new InterviewSlot("S3", "APP-3", "CAN-3", "INT-1", GradeBand.G5,
                InterviewRound.L1, LocalDateTime.of(monday, LocalTime.of(14, 0)), LocalDateTime.of(monday, LocalTime.of(15, 0))));

        assertEquals(3, interviewerG5.getInterviewCountOn(monday));
        assertTrue(interviewerG5.hasReachedDailyLimit(monday));

        // Attempting to book a 4th slot on Monday must not succeed on Monday
        boolean availableOnMonday = interviewerG5.isAvailable(
                LocalDateTime.of(monday, LocalTime.of(16, 0)),
                LocalDateTime.of(monday, LocalTime.of(17, 0)), 15);
        assertFalse(availableOnMonday, "Interviewer cannot exceed 3 interviews per day");
    }

    @Test
    @DisplayName("BR-10, BR-11 / Module A: Minimum 15-minute gap and overlap prevention")
    void testGapAndOverlapRules() {
        LocalDate date = LocalDate.of(2026, 3, 2);
        // Existing booking 10:00 to 11:00
        interviewerG5.bookSlot(new InterviewSlot("S1", "APP-1", "CAN-1", "INT-1", GradeBand.G5,
                InterviewRound.L1, LocalDateTime.of(date, LocalTime.of(10, 0)), LocalDateTime.of(date, LocalTime.of(11, 0))));

        // Overlapping slot 10:30 to 11:30 -> invalid
        assertFalse(interviewerG5.isAvailable(
                LocalDateTime.of(date, LocalTime.of(10, 30)),
                LocalDateTime.of(date, LocalTime.of(11, 30)), 15));

        // Slot immediately after at 11:05 (gap of 5 minutes < 15 min) -> invalid
        assertFalse(interviewerG5.isAvailable(
                LocalDateTime.of(date, LocalTime.of(11, 5)),
                LocalDateTime.of(date, LocalTime.of(12, 5)), 15));

        // Slot exactly 15 minutes after at 11:15 to 12:15 -> valid
        assertTrue(interviewerG5.isAvailable(
                LocalDateTime.of(date, LocalTime.of(11, 15)),
                LocalDateTime.of(date, LocalTime.of(12, 15)), 15));
    }

    @Test
    @DisplayName("BR-12 / Module A: L2 panel must include interviewer at least one grade higher than target grade")
    void testL2PanelGradeRequirement() {
        // Target candidate grade is G4.
        // interviewerG3 has G3 (lower) -> not eligible for L2 of G4.
        // interviewerG5 has G5 (higher by 1) -> eligible.
        LocalDate monday = LocalDate.of(2026, 3, 2);

        InterviewSchedulingResult res = scheduler.scheduleInterview(applicationG4, InterviewRound.L2, monday);
        assertTrue(res.success());
        assertEquals("INT-1", res.bookedSlot().getInterviewerId(), "Must assign G5 interviewer to G4 candidate L2 round");

        // If only G3 interviewer is available, L2 scheduling for G4 must fail with PANEL_GRADE_INSUFFICIENT
        InterviewScheduler g3OnlyScheduler = new InterviewScheduler(Collections.singletonList(interviewerG3), Collections.emptySet());
        InterviewSchedulingResult failRes = g3OnlyScheduler.scheduleInterview(applicationG4, InterviewRound.L2, monday);
        assertFalse(failRes.success());
        assertEquals(ReasonCode.PANEL_GRADE_INSUFFICIENT, failRes.reasonCode());
    }

    @Test
    @DisplayName("BR-13 / Module A: Exclude weekends and supplied holidays")
    void testExcludeWeekendsAndHolidays() {
        LocalDate friday = LocalDate.of(2026, 3, 6);
        LocalDate holidayMonday = LocalDate.of(2026, 3, 9); // Holi

        Set<LocalDate> holidays = new HashSet<>();
        holidays.add(holidayMonday);

        InterviewScheduler holidayScheduler = new InterviewScheduler(Collections.singletonList(interviewerG5), holidays);

        // Saturday (March 7) and Sunday (March 8) are weekends
        assertFalse(holidayScheduler.isWorkingDay(LocalDate.of(2026, 3, 7)));
        assertFalse(holidayScheduler.isWorkingDay(LocalDate.of(2026, 3, 8)));
        // March 9 is holiday
        assertFalse(holidayScheduler.isWorkingDay(holidayMonday));
        // Tuesday March 10 is next working day
        assertTrue(holidayScheduler.isWorkingDay(LocalDate.of(2026, 3, 10)));
    }

    @Test
    @DisplayName("DEC-03 / Module A: Interview ending exactly at availability window boundary is valid")
    void testInterviewEndingAtWindowBoundary() {
        LocalDate date = LocalDate.of(2026, 3, 2);
        // Window ends at 18:00. An L1 interview (60 mins) from 17:00 to 18:00 ends exactly at 18:00
        LocalDateTime start = LocalDateTime.of(date, LocalTime.of(17, 0));
        LocalDateTime end = LocalDateTime.of(date, LocalTime.of(18, 0));

        assertTrue(interviewerG5.isAvailable(start, end, 15));

        // An interview ending at 18:01 is past window -> invalid
        assertFalse(interviewerG5.isAvailable(
                LocalDateTime.of(date, LocalTime.of(17, 1)),
                LocalDateTime.of(date, LocalTime.of(18, 1)), 15));
    }
}

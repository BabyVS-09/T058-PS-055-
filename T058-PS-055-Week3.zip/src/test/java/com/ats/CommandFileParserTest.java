package com.ats;

import com.ats.model.CandidateStage;
import com.ats.model.ReasonCode;
import com.ats.parser.CommandExecutionResult;
import com.ats.parser.CommandFileParser;
import com.ats.service.RecruitmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CommandFileParserTest {

    private RecruitmentService recruitmentService;
    private CommandFileParser parser;

    @BeforeEach
    void setUp() {
        recruitmentService = new RecruitmentService();
        parser = new CommandFileParser(recruitmentService);
    }

    @Test
    @DisplayName("BR-38: Parse and execute REGISTER_REQUISITION, REGISTER_CANDIDATE, APPLY")
    void testBasicCommands() {
        CommandExecutionResult r1 = parser.executeLine(1,
                "REGISTER_REQUISITION | REQ-101 | Senior Java Backend Engineer | G4 | 2 | Bengaluru | 1400000 | 2200000 | Vikram Desai | 2026-03-01");
        assertTrue(r1.success());

        CommandExecutionResult r2 = parser.executeLine(2,
                "REGISTER_CANDIDATE | CAN-201 | Aarav Kulkarni | 30 | 1350000 | 1800000 | 5.5 | REFERRAL");
        assertTrue(r2.success());

        CommandExecutionResult r3 = parser.executeLine(3,
                "APPLY | APP-301 | CAN-201 | REQ-101 | 2026-03-05");
        assertTrue(r3.success());
    }

    @Test
    @DisplayName("BR-38: Parse and execute full offer and approval workflow")
    void testOfferAndApprovalCommands() {
        parser.executeLine(1, "REGISTER_REQUISITION | REQ-101 | Senior Java Backend Engineer | G4 | 2 | Bengaluru | 1400000 | 2200000 | Vikram Desai | 2026-03-01");
        parser.executeLine(2, "REGISTER_CANDIDATE | CAN-201 | Aarav Kulkarni | 30 | 1350000 | 1800000 | 5.5 | REFERRAL");
        parser.executeLine(3, "APPLY | APP-301 | CAN-201 | REQ-101 | 2026-03-05");
        parser.executeLine(4, "TRANSITION_STAGE | APP-301 | L1");
        parser.executeLine(5, "RECORD_SCORE | APP-301 | L1 | 4.2");
        parser.executeLine(6, "TRANSITION_STAGE | APP-301 | L2");
        parser.executeLine(7, "RECORD_SCORE | APP-301 | L2 | 4.0");
        parser.executeLine(8, "TRANSITION_STAGE | APP-301 | HR");

        CommandExecutionResult rOffer = parser.executeLine(9,
                "DRAFT_OFFER | OFF-501 | APP-301 | 2026-03-10 | 2026-03-30 | false");
        assertTrue(rOffer.success());

        CommandExecutionResult rApprReq = parser.executeLine(10,
                "REQUEST_APPROVAL | APPR-601 | OFF-501 | 2026-03-10");
        assertTrue(rApprReq.success());

        CommandExecutionResult rApprDec = parser.executeLine(11,
                "RECORD_APPROVAL | APPR-601 | HIRING_MANAGER | APPROVE | Excellent candidate");
        assertTrue(rApprDec.success());

        CommandExecutionResult rAccept = parser.executeLine(12,
                "ACCEPT_OFFER | APP-301 | 2026-03-12T10:00:00");
        assertTrue(rAccept.success());
        assertEquals(CandidateStage.ACCEPTED, recruitmentService.getApplication("APP-301").getCurrentStage());
    }

    @Test
    @DisplayName("BR-38: Handle invalid line syntax and unknown command")
    void testInvalidCommands() {
        CommandExecutionResult r1 = parser.executeLine(1, "UNKNOWN_CMD | foo | bar");
        assertFalse(r1.success());
        assertEquals(ReasonCode.UNKNOWN_COMMAND, r1.reasonCode());

        CommandExecutionResult r2 = parser.executeLine(2, "REGISTER_REQUISITION | incomplete");
        assertFalse(r2.success());
        assertEquals(ReasonCode.MISSING_REQUIRED_FIELD, r2.reasonCode());
    }

    @Test
    @DisplayName("BR-38: Parse multi-line file with comments and blanks")
    void testFileExecution() throws IOException {
        File tempFile = File.createTempFile("test-cmd-", ".txt");
        tempFile.deleteOnExit();

        try (FileWriter fw = new FileWriter(tempFile)) {
            fw.write("# Test comment\n");
            fw.write("\n");
            fw.write("REGISTER_REQUISITION | REQ-1 | Dev | G3 | 1 | Pune | 800000 | 1200000 | Manager | 2026-03-01\n");
            fw.write("SUMMARY\n");
        }

        List<CommandExecutionResult> results = parser.parseAndExecute(tempFile);
        assertEquals(2, results.size());
        assertTrue(results.get(0).success());
        assertTrue(results.get(1).success());
    }
}
